import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Mic, MicOff, Volume2, VolumeX, MessageSquare, Zap } from 'lucide-react';
import { VoiceCommandInterface, processVoiceCommand, narrateText, stopNarration } from '../lib/voiceInterface';
import { INDIAN_LANGUAGES } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';

export const VoiceCommands: React.FC = () => {
  const [voiceInterface] = useState(() => new VoiceCommandInterface());
  const [isListening, setIsListening] = useState(false);
  const [isNarrating, setIsNarrating] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('english');
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const [commandHistory, setCommandHistory] = useState<Array<{
    command: string;
    response: string;
    timestamp: Date;
  }>>([]);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    voiceInterface.setLanguage(selectedLanguage);
  }, [selectedLanguage, voiceInterface]);

  const startListening = () => {
    if (!voiceInterface.isSupported()) {
      setError('Voice recognition is not supported in this browser');
      return;
    }

    setError('');
    setIsListening(true);
    
    voiceInterface.startListening(
      async (transcript) => {
        setTranscript(transcript);
        setIsListening(false);
        
        try {
          const result = await processVoiceCommand(transcript, selectedLanguage);
          
          let responseText = '';
          
          if (result.confidence > 0.7) {
            // High confidence - execute the action
            responseText = `I'll help you ${result.action.replace('_', ' ')}. `;
            
            // Navigate to the appropriate page
            switch (result.action) {
              case 'content_generator':
                navigate('/content-generator');
                responseText += 'Opening the Content Generator.';
                break;
              case 'worksheet_creator':
                navigate('/worksheet-creator');
                responseText += 'Opening the Worksheet Creator.';
                break;
              case 'knowledge_base':
                navigate('/knowledge-base');
                responseText += 'Opening the Knowledge Base.';
                break;
              case 'visual_aids':
                navigate('/visual-aids');
                responseText += 'Opening Visual Aids Generator.';
                break;
              case 'lesson_planner':
                navigate('/lesson-planner');
                responseText += 'Opening the Lesson Planner.';
                break;
              case 'game_generator':
                navigate('/game-generator');
                responseText += 'Opening the Game Generator.';
                break;
              case 'audio_assessment':
                navigate('/audio-assessment');
                responseText += 'Opening Audio Assessment.';
                break;
              default:
                responseText += result.clarification || 'I can help you with that.';
            }
          } else {
            // Lower confidence - ask for clarification
            responseText = result.clarification || "I'm not sure I understood that correctly. Could you please rephrase your request?";
          }
          
          setResponse(responseText);
          
          // Add to history
          setCommandHistory(prev => [{
            command: transcript,
            response: responseText,
            timestamp: new Date()
          }, ...prev.slice(0, 9)]); // Keep last 10 commands
          
        } catch (err) {
          setError('Failed to process voice command. Please try again.');
          setIsListening(false);
        }
      },
      (error) => {
        setError(error);
        setIsListening(false);
      }
    );
  };

  const stopListening = () => {
    voiceInterface.stopListening();
    setIsListening(false);
  };

  const handleNarrate = async (text: string) => {
    if (isNarrating) {
      stopNarration();
      setIsNarrating(false);
      return;
    }

    try {
      setIsNarrating(true);
      await narrateText(text, selectedLanguage);
      setIsNarrating(false);
    } catch (error) {
      setError('Failed to narrate text. Please try again.');
      setIsNarrating(false);
    }
  };

  const exampleCommands = [
    "Create a math quiz for grade 3 in Hindi",
    "Generate a worksheet about animals",
    "Make a story about friendship",
    "Open the lesson planner",
    "Create visual aids for water cycle",
    "Help me with reading assessment"
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-purple-100 rounded-2xl">
            <Mic className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-slate-800 mb-2">
          Voice Commands
        </h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Control Sahayak with your voice - perfect for hands-free teaching
        </p>
      </motion.div>

      {/* Language Selection */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
      >
        <h2 className="text-lg font-semibold text-slate-800 mb-4">Voice Language</h2>
        <select
          value={selectedLanguage}
          onChange={(e) => setSelectedLanguage(e.target.value)}
          className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
        >
          {INDIAN_LANGUAGES.map((lang) => (
            <option key={lang.value} value={lang.value}>
              {lang.flag} {lang.label} ({lang.native})
            </option>
          ))}
        </select>
      </motion.div>

      {/* Voice Interface */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl p-8 shadow-sm border border-slate-200 text-center"
      >
        <div className="mb-6">
          <button
            onClick={isListening ? stopListening : startListening}
            disabled={!voiceInterface.isSupported()}
            className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 ${
              isListening
                ? 'bg-red-500 hover:bg-red-600 animate-pulse'
                : 'bg-purple-500 hover:bg-purple-600'
            } ${!voiceInterface.isSupported() ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {isListening ? (
              <MicOff className="w-10 h-10 text-white" />
            ) : (
              <Mic className="w-10 h-10 text-white" />
            )}
          </button>
        </div>

        <p className="text-lg text-slate-700 mb-2">
          {isListening ? 'Listening...' : 'Click to start voice command'}
        </p>
        
        {!voiceInterface.isSupported() && (
          <p className="text-sm text-red-600">
            Voice recognition is not supported in this browser
          </p>
        )}

        {transcript && (
          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h3 className="font-medium text-blue-800 mb-2">You said:</h3>
            <p className="text-blue-700">"{transcript}"</p>
          </div>
        )}

        {response && (
          <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium text-green-800">Sahayak responds:</h3>
              <button
                onClick={() => handleNarrate(response)}
                className="p-2 text-green-600 hover:text-green-800 hover:bg-green-100 rounded-lg transition-colors"
              >
                {isNarrating ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-green-700">{response}</p>
          </div>
        )}

        {error && (
          <div className="mt-4 p-4 bg-red-50 rounded-lg border border-red-200">
            <p className="text-red-700">{error}</p>
          </div>
        )}
      </motion.div>

      {/* Example Commands */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
      >
        <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
          <MessageSquare className="w-5 h-5 mr-2 text-purple-500" />
          Example Voice Commands
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {exampleCommands.map((command, index) => (
            <button
              key={index}
              onClick={() => setTranscript(command)}
              className="p-3 text-left text-sm text-slate-600 hover:text-slate-800 hover:bg-slate-50 rounded-lg transition-colors border border-slate-200 hover:border-purple-300"
            >
              "{command}"
            </button>
          ))}
        </div>
      </motion.div>

      {/* Command History */}
      {commandHistory.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
        >
          <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
            <Zap className="w-5 h-5 mr-2 text-purple-500" />
            Recent Commands
          </h2>
          
          <div className="space-y-4">
            {commandHistory.map((item, index) => (
              <div key={index} className="border-l-4 border-purple-200 pl-4">
                <div className="flex items-center justify-between mb-1">
                  <p className="font-medium text-slate-800">"{item.command}"</p>
                  <span className="text-xs text-slate-500">
                    {item.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                <p className="text-sm text-slate-600">{item.response}</p>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Tips */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-200"
      >
        <h3 className="text-lg font-semibold text-slate-800 mb-4">
          🎤 Voice Command Tips
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-purple-600 mr-2">•</span>
              Speak clearly and at a normal pace
            </p>
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-purple-600 mr-2">•</span>
              Include specific details like grade level and subject
            </p>
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-purple-600 mr-2">•</span>
              Use action words like "create", "generate", "make"
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-purple-600 mr-2">•</span>
              Try different phrasings if not understood
            </p>
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-purple-600 mr-2">•</span>
              Ensure good microphone access in browser
            </p>
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-purple-600 mr-2">•</span>
              Works best in quiet environments
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};