import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Globe, Users, Sparkles, Copy, Download } from 'lucide-react';
import { INDIAN_LANGUAGES } from '../lib/supabase';

export const ContentGenerator: React.FC = () => {
  const [language, setLanguage] = useState('english');
  const [contentType, setContentType] = useState('story');
  const [topic, setTopic] = useState('');
  const [gradeLevel, setGradeLevel] = useState('mixed');
  const [generatedContent, setGeneratedContent] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const contentTypes = [
    { value: 'story', label: 'Story', emoji: '📚' },
    { value: 'explanation', label: 'Concept Explanation', emoji: '💡' },
    { value: 'example', label: 'Real-world Example', emoji: '🌍' },
    { value: 'analogy', label: 'Simple Analogy', emoji: '🔗' },
    { value: 'poem', label: 'Educational Poem', emoji: '📝' },
    { value: 'dialogue', label: 'Character Dialogue', emoji: '💬' },
  ];

  const gradeLevels = [
    { value: 'mixed', label: 'Mixed Grades (1-5)' },
    { value: 'primary', label: 'Primary (1-2)' },
    { value: 'elementary', label: 'Elementary (3-5)' },
    { value: 'middle', label: 'Middle (6-8)' },
  ];

  const handleGenerate = async () => {
    setIsGenerating(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock generated content
    const mockContent = `Once upon a time in a small village in Maharashtra, there lived a farmer named Ravi who taught the children about different types of soil...

This story helps explain:
• Black soil (કાળી માટી) - Rich in nutrients, good for cotton
• Red soil (લાલ માટી) - Good for groundnuts and millets  
• Sandy soil (રેતાળ માટી) - Drains water quickly

The children could see these soil types right in their own village fields, making the lesson come alive!`;

    setGeneratedContent(mockContent);
    setIsGenerating(false);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedContent);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-primary-100 rounded-2xl">
            <FileText className="w-8 h-8 text-primary-600" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-slate-800 mb-2">
          Hyper-Local Content Generator
        </h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Create culturally relevant, locally contextualized content in your preferred language
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Panel */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
        >
          <h2 className="text-xl font-semibold text-slate-800 mb-6 flex items-center">
            <Sparkles className="w-5 h-5 mr-2 text-primary-500" />
            Content Parameters
          </h2>

          <div className="space-y-6">
            {/* Language Selection */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                <Globe className="w-4 h-4 inline mr-2" />
                Choose Language
              </label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              >
                {INDIAN_LANGUAGES.map((lang) => (
                  <option key={lang.value} value={lang.value}>
                    {lang.flag} {lang.label} ({lang.native})
                  </option>
                ))}
              </select>
            </div>

            {/* Content Type */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                Content Type
              </label>
              <div className="grid grid-cols-2 gap-2">
                {contentTypes.map((type) => (
                  <button
                    key={type.value}
                    onClick={() => setContentType(type.value)}
                    className={`p-3 rounded-lg border-2 transition-colors text-left ${
                      contentType === type.value
                        ? 'border-primary-500 bg-primary-50'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <span className="mr-2">{type.emoji}</span>
                    <span className="font-medium text-sm">{type.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Grade Level */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                <Users className="w-4 h-4 inline mr-2" />
                Target Grade Level
              </label>
              <select
                value={gradeLevel}
                onChange={(e) => setGradeLevel(e.target.value)}
                className="w-full p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              >
                {gradeLevels.map((grade) => (
                  <option key={grade.value} value={grade.value}>
                    {grade.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Topic Input */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                Topic or Request
              </label>
              <textarea
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="Example: Create a story about farmers to explain different soil types"
                className="w-full p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 h-24 resize-none"
              />
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={!topic.trim() || isGenerating}
              className="w-full py-3 px-4 bg-primary-500 text-white rounded-lg font-semibold hover:bg-primary-600 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              {isGenerating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Generating Content...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Generate Content
                </>
              )}
            </button>
          </div>
        </motion.div>

        {/* Output Panel */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-slate-800">
              Generated Content
            </h2>
            {generatedContent && (
              <div className="flex space-x-2">
                <button
                  onClick={copyToClipboard}
                  className="p-2 text-slate-600 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                  title="Copy to clipboard"
                >
                  <Copy className="w-4 h-4" />
                </button>
                <button
                  className="p-2 text-slate-600 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                  title="Download as text file"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          <div className="min-h-[400px]">
            {generatedContent ? (
              <div className="bg-slate-50 rounded-lg p-4 whitespace-pre-wrap text-slate-700 leading-relaxed">
                {generatedContent}
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-slate-400">
                <div className="text-center">
                  <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Generated content will appear here</p>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Examples Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-200"
      >
        <h3 className="text-lg font-semibold text-slate-800 mb-4">
          Example Requests You Can Make:
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <p className="text-sm text-slate-700">
              • "Create a Marathi story about local birds to teach counting"
            </p>
            <p className="text-sm text-slate-700">
              • "Explain photosynthesis using village farming examples"
            </p>
            <p className="text-sm text-slate-700">
              • "Write a simple poem about water cycle in Hindi"
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-slate-700">
              • "Create dialogues between animals to teach moral values"
            </p>
            <p className="text-sm text-slate-700">
              • "Explain fractions using local sweets and food examples"
            </p>
            <p className="text-sm text-slate-700">
              • "Make a story about local festivals to teach history"
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};