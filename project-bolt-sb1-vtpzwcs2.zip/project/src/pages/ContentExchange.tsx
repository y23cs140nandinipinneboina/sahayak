import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Share2, ThumbsUp, Download, MessageCircle, Upload, Search, Filter } from 'lucide-react';
import { SharedContent, shareContent, getSharedContent, upvoteContent, downloadContent } from '../lib/contentSharing';

export const ContentExchange: React.FC = () => {
  const [sharedContent, setSharedContent] = useState<SharedContent[]>([]);
  const [showShareForm, setShowShareForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSubject, setFilterSubject] = useState('');
  const [filterGrade, setFilterGrade] = useState('');
  const [loading, setLoading] = useState(true);

  const [shareForm, setShareForm] = useState({
    title: '',
    description: '',
    contentType: 'worksheet' as const,
    subject: '',
    gradeLevel: '',
    language: 'english',
    content: '',
    authorName: '',
    schoolName: '',
    tags: [] as string[]
  });

  useEffect(() => {
    const unsubscribe = getSharedContent((content) => {
      setSharedContent(content);
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const handleShare = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await shareContent(shareForm);
      setShowShareForm(false);
      setShareForm({
        title: '',
        description: '',
        contentType: 'worksheet',
        subject: '',
        gradeLevel: '',
        language: 'english',
        content: '',
        authorName: '',
        schoolName: '',
        tags: []
      });
    } catch (error) {
      console.error('Error sharing content:', error);
    }
  };

  const handleUpvote = async (contentId: string) => {
    try {
      await upvoteContent(contentId);
    } catch (error) {
      console.error('Error upvoting content:', error);
    }
  };

  const handleDownload = async (content: SharedContent) => {
    try {
      await downloadContent(content.id!);
      
      // Create downloadable content
      const blob = new Blob([content.content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${content.title}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading content:', error);
    }
  };

  const filteredContent = sharedContent.filter(content => {
    const matchesSearch = content.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         content.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         content.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesSubject = !filterSubject || content.subject === filterSubject;
    const matchesGrade = !filterGrade || content.gradeLevel === filterGrade;
    
    return matchesSearch && matchesSubject && matchesGrade;
  });

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case 'worksheet': return '📄';
      case 'story': return '📚';
      case 'visual_aid': return '🎨';
      case 'lesson_plan': return '📅';
      case 'game': return '🎮';
      default: return '📝';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold text-slate-800 flex items-center">
            <Share2 className="w-8 h-8 mr-3 text-primary-500" />
            Sahayak Exchange
          </h1>
          <p className="text-lg text-slate-600 mt-2">
            Share and discover educational content created by teachers
          </p>
        </div>
        
        <button
          onClick={() => setShowShareForm(true)}
          className="px-6 py-3 bg-primary-500 text-white rounded-xl font-semibold hover:bg-primary-600 transition-colors flex items-center"
        >
          <Upload className="w-5 h-5 mr-2" />
          Share Content
        </button>
      </motion.div>

      {/* Search and Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
      >
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search content, tags, or descriptions..."
                className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
          </div>
          
          <div>
            <select
              value={filterSubject}
              onChange={(e) => setFilterSubject(e.target.value)}
              className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="">All Subjects</option>
              <option value="Mathematics">Mathematics</option>
              <option value="Science">Science</option>
              <option value="English">English</option>
              <option value="Hindi">Hindi</option>
              <option value="Social Studies">Social Studies</option>
            </select>
          </div>
          
          <div>
            <select
              value={filterGrade}
              onChange={(e) => setFilterGrade(e.target.value)}
              className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="">All Grades</option>
              <option value="1-2">Grades 1-2</option>
              <option value="3-4">Grades 3-4</option>
              <option value="5-6">Grades 5-6</option>
              <option value="7-8">Grades 7-8</option>
            </select>
          </div>
        </div>
      </motion.div>

      {/* Share Form */}
      {showShareForm && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
        >
          <h2 className="text-xl font-semibold text-slate-800 mb-4">Share Your Content</h2>
          
          <form onSubmit={handleShare} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Title *</label>
                <input
                  type="text"
                  value={shareForm.title}
                  onChange={(e) => setShareForm(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Content Type</label>
                <select
                  value={shareForm.contentType}
                  onChange={(e) => setShareForm(prev => ({ ...prev, contentType: e.target.value as any }))}
                  className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="worksheet">Worksheet</option>
                  <option value="story">Story</option>
                  <option value="visual_aid">Visual Aid</option>
                  <option value="lesson_plan">Lesson Plan</option>
                  <option value="game">Game</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Subject</label>
                <input
                  type="text"
                  value={shareForm.subject}
                  onChange={(e) => setShareForm(prev => ({ ...prev, subject: e.target.value }))}
                  className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Grade Level</label>
                <input
                  type="text"
                  value={shareForm.gradeLevel}
                  onChange={(e) => setShareForm(prev => ({ ...prev, gradeLevel: e.target.value }))}
                  placeholder="e.g., 3-4"
                  className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Your Name</label>
                <input
                  type="text"
                  value={shareForm.authorName}
                  onChange={(e) => setShareForm(prev => ({ ...prev, authorName: e.target.value }))}
                  className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">School (Optional)</label>
                <input
                  type="text"
                  value={shareForm.schoolName}
                  onChange={(e) => setShareForm(prev => ({ ...prev, schoolName: e.target.value }))}
                  className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Description</label>
              <textarea
                value={shareForm.description}
                onChange={(e) => setShareForm(prev => ({ ...prev, description: e.target.value }))}
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 h-24 resize-none"
                placeholder="Describe your content and how other teachers can use it..."
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Content *</label>
              <textarea
                value={shareForm.content}
                onChange={(e) => setShareForm(prev => ({ ...prev, content: e.target.value }))}
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 h-32 resize-none"
                placeholder="Paste your content here..."
                required
              />
            </div>
            
            <div className="flex space-x-4">
              <button
                type="submit"
                className="px-6 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600 transition-colors"
              >
                Share Content
              </button>
              <button
                type="button"
                onClick={() => setShowShareForm(false)}
                className="px-6 py-2 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Content Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredContent.map((content, index) => (
          <motion.div
            key={content.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 hover:shadow-md transition-shadow"
          >
            {/* Content Header */}
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center">
                <span className="text-2xl mr-2">{getContentTypeIcon(content.contentType)}</span>
                <div>
                  <h3 className="font-semibold text-slate-800 line-clamp-1">{content.title}</h3>
                  <p className="text-sm text-slate-600">{content.subject} • Grade {content.gradeLevel}</p>
                </div>
              </div>
            </div>

            {/* Description */}
            <p className="text-sm text-slate-700 mb-4 line-clamp-3">{content.description}</p>

            {/* Tags */}
            <div className="flex flex-wrap gap-1 mb-4">
              {content.tags.slice(0, 3).map(tag => (
                <span key={tag} className="px-2 py-1 bg-slate-100 text-slate-600 rounded text-xs">
                  {tag}
                </span>
              ))}
            </div>

            {/* Author */}
            <div className="text-xs text-slate-500 mb-4">
              By {content.authorName}
              {content.schoolName && ` • ${content.schoolName}`}
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => handleUpvote(content.id!)}
                  className="flex items-center text-slate-600 hover:text-primary-600 transition-colors"
                >
                  <ThumbsUp className="w-4 h-4 mr-1" />
                  <span className="text-sm">{content.upvotes}</span>
                </button>
                
                <span className="flex items-center text-slate-500 text-sm">
                  <Download className="w-4 h-4 mr-1" />
                  {content.downloads}
                </span>
              </div>
              
              <button
                onClick={() => handleDownload(content)}
                className="px-3 py-1 bg-primary-500 text-white rounded-lg hover:bg-primary-600 transition-colors text-sm"
              >
                Download
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {filteredContent.length === 0 && (
        <div className="text-center py-12">
          <Share2 className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-600 mb-2">No content found</h3>
          <p className="text-slate-500 mb-4">
            {searchTerm || filterSubject || filterGrade 
              ? 'Try adjusting your search or filters'
              : 'Be the first to share educational content with the community'
            }
          </p>
          {!searchTerm && !filterSubject && !filterGrade && (
            <button
              onClick={() => setShowShareForm(true)}
              className="px-6 py-3 bg-primary-500 text-white rounded-xl font-semibold hover:bg-primary-600 transition-colors"
            >
              Share Your First Content
            </button>
          )}
        </div>
      )}
    </div>
  );
};