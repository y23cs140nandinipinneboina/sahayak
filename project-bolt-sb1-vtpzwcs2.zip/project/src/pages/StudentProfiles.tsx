import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Plus, Edit, Trash2, TrendingUp, Mic, BookOpen, Award } from 'lucide-react';
import { StudentProfile, createStudentProfile, getStudentProfiles, updateStudentProfile, deleteStudentProfile } from '../lib/studentProfiles';

export const StudentProfiles: React.FC = () => {
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingStudent, setEditingStudent] = useState<StudentProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const [formData, setFormData] = useState({
    name: '',
    grade: 1,
    readingLevel: 'beginner' as const,
    subjects: [] as string[],
    notes: ''
  });

  useEffect(() => {
    loadStudents();
  }, []);

  const loadStudents = async () => {
    try {
      const studentList = await getStudentProfiles();
      setStudents(studentList);
    } catch (error) {
      console.error('Error loading students:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const studentData = {
        ...formData,
        progressScores: {
          reading: 0,
          math: 0,
          science: 0,
          overall: 0
        }
      };

      if (editingStudent) {
        await updateStudentProfile(editingStudent.id!, studentData);
      } else {
        await createStudentProfile(studentData);
      }

      await loadStudents();
      resetForm();
    } catch (error) {
      console.error('Error saving student:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      grade: 1,
      readingLevel: 'beginner',
      subjects: [],
      notes: ''
    });
    setShowAddForm(false);
    setEditingStudent(null);
  };

  const handleEdit = (student: StudentProfile) => {
    setFormData({
      name: student.name,
      grade: student.grade,
      readingLevel: student.readingLevel,
      subjects: student.subjects,
      notes: student.notes
    });
    setEditingStudent(student);
    setShowAddForm(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this student profile?')) {
      try {
        await deleteStudentProfile(id);
        await loadStudents();
      } catch (error) {
        console.error('Error deleting student:', error);
      }
    }
  };

  const getProgressColor = (score: number) => {
    if (score >= 80) return 'text-green-600 bg-green-100';
    if (score >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getReadingLevelColor = (level: string) => {
    switch (level) {
      case 'advanced': return 'bg-green-100 text-green-800';
      case 'intermediate': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold text-slate-800 flex items-center">
            <Users className="w-8 h-8 mr-3 text-primary-500" />
            Student Profiles
          </h1>
          <p className="text-lg text-slate-600 mt-2">
            Manage your class roster and track student progress
          </p>
        </div>
        
        <button
          onClick={() => setShowAddForm(true)}
          className="px-6 py-3 bg-primary-500 text-white rounded-xl font-semibold hover:bg-primary-600 transition-colors flex items-center"
        >
          <Plus className="w-5 h-5 mr-2" />
          Add Student
        </button>
      </motion.div>

      {/* Add/Edit Form */}
      {showAddForm && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
        >
          <h2 className="text-xl font-semibold text-slate-800 mb-4">
            {editingStudent ? 'Edit Student' : 'Add New Student'}
          </h2>
          
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Student Name *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Grade Level *
              </label>
              <select
                value={formData.grade}
                onChange={(e) => setFormData(prev => ({ ...prev, grade: parseInt(e.target.value) }))}
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              >
                {[1, 2, 3, 4, 5, 6, 7, 8].map(grade => (
                  <option key={grade} value={grade}>Grade {grade}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Reading Level
              </label>
              <select
                value={formData.readingLevel}
                onChange={(e) => setFormData(prev => ({ ...prev, readingLevel: e.target.value as any }))}
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              >
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Subjects
              </label>
              <div className="grid grid-cols-2 gap-2">
                {['Math', 'Science', 'English', 'Hindi', 'Social Studies'].map(subject => (
                  <label key={subject} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={formData.subjects.includes(subject)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setFormData(prev => ({ ...prev, subjects: [...prev.subjects, subject] }));
                        } else {
                          setFormData(prev => ({ ...prev, subjects: prev.subjects.filter(s => s !== subject) }));
                        }
                      }}
                      className="mr-2"
                    />
                    <span className="text-sm">{subject}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Notes
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 h-24 resize-none"
                placeholder="Any additional notes about the student..."
              />
            </div>

            <div className="md:col-span-2 flex space-x-4">
              <button
                type="submit"
                className="px-6 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600 transition-colors"
              >
                {editingStudent ? 'Update Student' : 'Add Student'}
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="px-6 py-2 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Students Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {students.map((student, index) => (
          <motion.div
            key={student.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 hover:shadow-md transition-shadow"
          >
            {/* Student Header */}
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-slate-800">{student.name}</h3>
                <p className="text-sm text-slate-600">Grade {student.grade}</p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleEdit(student)}
                  className="p-2 text-slate-600 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(student.id!)}
                  className="p-2 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Reading Level */}
            <div className="mb-4">
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getReadingLevelColor(student.readingLevel)}`}>
                {student.readingLevel.charAt(0).toUpperCase() + student.readingLevel.slice(1)} Reader
              </span>
            </div>

            {/* Progress Scores */}
            <div className="space-y-3 mb-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600 flex items-center">
                  <BookOpen className="w-4 h-4 mr-1" />
                  Reading
                </span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getProgressColor(student.progressScores.reading)}`}>
                  {student.progressScores.reading}%
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600 flex items-center">
                  <TrendingUp className="w-4 h-4 mr-1" />
                  Math
                </span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getProgressColor(student.progressScores.math)}`}>
                  {student.progressScores.math}%
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-600 flex items-center">
                  <Award className="w-4 h-4 mr-1" />
                  Overall
                </span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getProgressColor(student.progressScores.overall)}`}>
                  {student.progressScores.overall}%
                </span>
              </div>
            </div>

            {/* Subjects */}
            <div className="mb-4">
              <p className="text-xs text-slate-500 mb-2">Subjects:</p>
              <div className="flex flex-wrap gap-1">
                {student.subjects.map(subject => (
                  <span key={subject} className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-xs">
                    {subject}
                  </span>
                ))}
              </div>
            </div>

            {/* Voice Sample */}
            <div className="pt-3 border-t border-slate-100">
              <button className="w-full py-2 px-3 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors flex items-center justify-center text-sm">
                <Mic className="w-4 h-4 mr-1" />
                Record Voice Sample
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {students.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-600 mb-2">No students added yet</h3>
          <p className="text-slate-500 mb-4">Start building your class roster by adding student profiles</p>
          <button
            onClick={() => setShowAddForm(true)}
            className="px-6 py-3 bg-primary-500 text-white rounded-xl font-semibold hover:bg-primary-600 transition-colors"
          >
            Add Your First Student
          </button>
        </div>
      )}
    </div>
  );
};