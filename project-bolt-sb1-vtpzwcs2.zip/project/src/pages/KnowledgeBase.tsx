import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { HelpCircle, Search, MessageCircle, Lightbulb, Globe, Clock } from 'lucide-react';
import { INDIAN_LANGUAGES } from '../lib/supabase';

interface QAItem {
  id: number;
  question: string;
  answer: string;
  category: string;
  language: string;
  timestamp: string;
}

export const KnowledgeBase: React.FC = () => {
  const [question, setQuestion] = useState('');
  const [language, setLanguage] = useState('english');
  const [isAsking, setIsAsking] = useState(false);
  const [currentAnswer, setCurrentAnswer] = useState('');
  const [recentQuestions, setRecentQuestions] = useState<QAItem[]>([
    {
      id: 1,
      question: "Why is the sky blue?",
      answer: "The sky appears blue because of how sunlight interacts with tiny particles in our atmosphere. Think of it like this: sunlight is like a box of crayons with all colors mixed together. When this light hits the tiny particles in the air, the blue color gets scattered around more than other colors, just like how blue paint spreads more when you mix it with water. That's why we see more blue light coming from all directions in the sky!",
      category: "Science",
      language: "English",
      timestamp: "2 minutes ago"
    },
    {
      id: 2,
      question: "पेड़ कैसे सांस लेते हैं?",
      answer: "पेड़ अपनी पत्तियों के छोटे-छोटे छिद्रों से सांस लेते हैं, जिन्हें स्टोमेटा कहते हैं। यह ऐसे है जैसे हमारी नाक में छोटे छिद्र हों। दिन में पेड़ कार्बन डाइऑक्साइड लेते हैं और ऑक्सीजन छोड़ते हैं, जैसे हम सांस लेते और छोड़ते हैं। इसीलिए पेड़ों के पास हवा साफ और ताजी लगती है!",
      category: "विज्ञान",
      language: "हिंदी",
      timestamp: "5 minutes ago"
    }
  ]);

  const quickQuestions = [
    "Why do we have seasons?",
    "How do plants make their food?",
    "What makes rain fall?",
    "Why is water important?",
    "How do birds fly?",
    "What is gravity?"
  ];

  const handleAskQuestion = async () => {
    if (!question.trim()) return;
    
    setIsAsking(true);
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockAnswer = "Great question! Let me explain this in a simple way that your students will easily understand. [This would be the AI-generated explanation with cultural context and analogies suitable for the classroom]";
    
    setCurrentAnswer(mockAnswer);
    
    // Add to recent questions
    const selectedLanguage = INDIAN_LANGUAGES.find(l => l.value === language);
    const newQA: QAItem = {
      id: Date.now(),
      question,
      answer: mockAnswer,
      category: "General",
      language: selectedLanguage?.label || "English",
      timestamp: "Just now"
    };
    
    setRecentQuestions([newQA, ...recentQuestions]);
    setQuestion('');
    setIsAsking(false);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-green-100 rounded-2xl">
            <HelpCircle className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-slate-800 mb-2">
          Instant Knowledge Base
        </h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Get simple, accurate explanations for any question your students might ask
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Question Input */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-2 space-y-6"
        >
          {/* Ask Question Card */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center">
              <MessageCircle className="w-5 h-5 mr-2 text-green-500" />
              Ask a Question
            </h2>

            {/* Language Selection */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                <Globe className="w-4 h-4 inline mr-1" />
                Response Language
              </label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500"
              >
                {INDIAN_LANGUAGES.map((lang) => (
                  <option key={lang.value} value={lang.value}>
                    {lang.flag} {lang.label} ({lang.native})
                  </option>
                ))}
              </select>
            </div>

            {/* Question Input */}
            <div className="mb-4">
              <textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Ask any question your students might have..."
                className="w-full p-4 border border-slate-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500 h-32 resize-none"
              />
            </div>

            <button
              onClick={handleAskQuestion}
              disabled={!question.trim() || isAsking}
              className="w-full py-3 px-4 bg-green-500 text-white rounded-xl font-semibold hover:bg-green-600 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              {isAsking ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Thinking...
                </>
              ) : (
                <>
                  <Search className="w-5 h-5 mr-2" />
                  Get Answer
                </>
              )}
            </button>
          </div>

          {/* Current Answer */}
          {currentAnswer && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-200"
            >
              <h3 className="text-lg font-semibold text-slate-800 mb-3 flex items-center">
                <Lightbulb className="w-5 h-5 mr-2 text-green-600" />
                Answer
              </h3>
              <p className="text-slate-700 leading-relaxed">{currentAnswer}</p>
            </motion.div>
          )}

          {/* Quick Questions */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">
              Popular Questions
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {quickQuestions.map((q, index) => (
                <button
                  key={index}
                  onClick={() => setQuestion(q)}
                  className="p-3 text-left text-sm text-slate-600 hover:text-slate-800 hover:bg-slate-50 rounded-lg transition-colors border border-transparent hover:border-slate-200"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Recent Questions Sidebar */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
              <Clock className="w-5 h-5 mr-2 text-blue-500" />
              Recent Questions
            </h3>
            
            <div className="space-y-4">
              {recentQuestions.map((qa) => (
                <div key={qa.id} className="border-b border-slate-100 pb-4 last:border-b-0">
                  <div className="flex items-start justify-between mb-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      qa.language === 'हिंदी' ? 'bg-orange-100 text-orange-800' :
                      qa.language === 'मराठी' ? 'bg-purple-100 text-purple-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {qa.language}
                    </span>
                    <span className="text-xs text-slate-400">{qa.timestamp}</span>
                  </div>
                  <h4 className="font-medium text-sm text-slate-800 mb-2 line-clamp-2">
                    {qa.question}
                  </h4>
                  <p className="text-xs text-slate-600 line-clamp-3">
                    {qa.answer}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Tips */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-4 border border-blue-200">
            <h4 className="font-semibold text-slate-800 mb-2">💡 Tips</h4>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Ask questions as your students would</li>
              <li>• Use simple, everyday language</li>
              <li>• The AI provides age-appropriate explanations</li>
              <li>• Answers include local context and analogies</li>
            </ul>
          </div>
        </motion.div>
      </div>
    </div>
  );
};