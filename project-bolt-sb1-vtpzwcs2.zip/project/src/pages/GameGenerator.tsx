import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Gamepad2, Zap, Users, Star, Play, Shuffle, Settings } from 'lucide-react';

interface Game {
  id: number;
  title: string;
  type: string;
  subject: string;
  grades: string;
  duration: string;
  materials: string[];
  instructions: string[];
  difficulty: 'Easy' | 'Medium' | 'Hard';
  playerCount: string;
}

export const GameGenerator: React.FC = () => {
  const [subject, setSubject] = useState('');
  const [topic, setTopic] = useState('');
  const [gameType, setGameType] = useState('');
  const [difficulty, setDifficulty] = useState('Medium');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedGames, setGeneratedGames] = useState<Game[]>([]);

  const subjects = [
    'Mathematics', 'Science', 'English', 'Hindi', 'Social Studies', 
    'Environmental Studies', 'General Knowledge'
  ];

  const gameTypes = [
    { value: 'quiz', label: 'Quiz Game', emoji: '❓', description: 'Question & answer format' },
    { value: 'memory', label: 'Memory Game', emoji: '🧠', description: 'Remember and match' },
    { value: 'word', label: 'Word Game', emoji: '📝', description: 'Spelling and vocabulary' },
    { value: 'math', label: 'Math Challenge', emoji: '🔢', description: 'Number games and puzzles' },
    { value: 'drawing', label: 'Drawing Game', emoji: '🎨', description: 'Visual creativity' },
    { value: 'role-play', label: 'Role Play', emoji: '🎭', description: 'Acting and scenarios' },
  ];

  const mockGames: Game[] = [
    {
      id: 1,
      title: 'Fraction Pizza Party',
      type: 'Interactive',
      subject: 'Mathematics',
      grades: '3-5',
      duration: '20 minutes',
      materials: ['Paper circles', 'Colored chalk', 'Blackboard'],
      instructions: [
        'Draw pizza circles on the blackboard',
        'Divide students into teams',
        'Call out fractions (1/2, 1/4, 3/4)',
        'Teams race to correctly shade the pizza slices',
        'First team to shade correctly gets a point'
      ],
      difficulty: 'Easy',
      playerCount: '15-30 students'
    },
    {
      id: 2,
      title: 'Ecosystem Web Game',
      type: 'Movement',
      subject: 'Science',
      grades: '4-6',
      duration: '25 minutes',
      materials: ['Ball of yarn', 'Animal cards', 'Open space'],
      instructions: [
        'Give each student an animal/plant card',
        'Students stand in a circle',
        'Start with the sun (energy source)',
        'Pass yarn to show who eats whom',
        'Create a visible food web',
        'Discuss what happens if one species disappears'
      ],
      difficulty: 'Medium',
      playerCount: '20-35 students'
    }
  ];

  const generateGames = async () => {
    setIsGenerating(true);
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 2500));
    setGeneratedGames(mockGames);
    setIsGenerating(false);
  };

  const getDifficultyColor = (diff: string) => {
    switch (diff) {
      case 'Easy': return 'bg-green-100 text-green-800 border-green-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Hard': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-rose-100 rounded-2xl">
            <Gamepad2 className="w-8 h-8 text-rose-600" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-slate-800 mb-2">
          Educational Game Generator
        </h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Create fun, engaging educational games that make learning interactive for all grade levels
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Panel */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
        >
          <h2 className="text-xl font-semibold text-slate-800 mb-6 flex items-center">
            <Settings className="w-5 h-5 mr-2 text-rose-500" />
            Game Parameters
          </h2>

          <div className="space-y-6">
            {/* Subject */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                Subject
              </label>
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
              >
                <option value="">Select Subject</option>
                {subjects.map((subj) => (
                  <option key={subj} value={subj}>{subj}</option>
                ))}
              </select>
            </div>

            {/* Topic */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                Topic/Concept
              </label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., Fractions, Animals, Solar System"
                className="w-full p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
              />
            </div>

            {/* Game Type */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                Game Type
              </label>
              <div className="grid grid-cols-2 gap-2">
                {gameTypes.map((type) => (
                  <button
                    key={type.value}
                    onClick={() => setGameType(type.value)}
                    className={`p-3 rounded-lg border-2 transition-colors text-left ${
                      gameType === type.value
                        ? 'border-rose-500 bg-rose-50'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="text-lg mb-1">{type.emoji}</div>
                    <div className="font-medium text-xs text-slate-800 mb-1">
                      {type.label}
                    </div>
                    <div className="text-xs text-slate-600">
                      {type.description}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Difficulty */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                Difficulty Level
              </label>
              <div className="flex space-x-2">
                {['Easy', 'Medium', 'Hard'].map((level) => (
                  <button
                    key={level}
                    onClick={() => setDifficulty(level)}
                    className={`flex-1 py-2 px-3 rounded-lg border-2 transition-colors text-sm font-medium ${
                      difficulty === level
                        ? 'border-rose-500 bg-rose-50 text-rose-700'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={generateGames}
              disabled={!subject || !topic || !gameType || isGenerating}
              className="w-full py-3 px-4 bg-rose-500 text-white rounded-xl font-semibold hover:bg-rose-600 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              {isGenerating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Creating Games...
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 mr-2" />
                  Generate Games
                </>
              )}
            </button>
          </div>
        </motion.div>

        {/* Generated Games */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-2 space-y-6"
        >
          {generatedGames.length > 0 ? (
            generatedGames.map((game) => (
              <div key={game.id} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                {/* Game Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-slate-800 mb-2">{game.title}</h3>
                    <div className="flex items-center space-x-4 text-sm text-slate-600">
                      <span className="flex items-center">
                        <Users className="w-4 h-4 mr-1" />
                        {game.playerCount}
                      </span>
                      <span className="flex items-center">
                        <Play className="w-4 h-4 mr-1" />
                        {game.duration}
                      </span>
                      <span>Grades {game.grades}</span>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getDifficultyColor(game.difficulty)}`}>
                    {game.difficulty}
                  </span>
                </div>

                {/* Materials Needed */}
                <div className="mb-4">
                  <h4 className="font-semibold text-slate-800 mb-2">Materials Needed:</h4>
                  <div className="flex flex-wrap gap-2">
                    {game.materials.map((material, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-slate-100 text-slate-700 rounded-lg text-sm"
                      >
                        {material}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Instructions */}
                <div className="mb-4">
                  <h4 className="font-semibold text-slate-800 mb-2">How to Play:</h4>
                  <ol className="space-y-2">
                    {game.instructions.map((instruction, index) => (
                      <li key={index} className="flex items-start text-sm text-slate-700">
                        <span className="bg-rose-100 text-rose-700 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold mr-3 mt-0.5 flex-shrink-0">
                          {index + 1}
                        </span>
                        {instruction}
                      </li>
                    ))}
                  </ol>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-3 pt-4 border-t border-slate-100">
                  <button className="flex-1 py-2 px-4 bg-rose-500 text-white rounded-lg hover:bg-rose-600 transition-colors flex items-center justify-center text-sm">
                    <Star className="w-4 h-4 mr-1" />
                    Save Favorite
                  </button>
                  <button className="flex-1 py-2 px-4 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors flex items-center justify-center text-sm">
                    <Shuffle className="w-4 h-4 mr-1" />
                    Create Variation
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
              <div className="text-center py-12 text-slate-400">
                <Gamepad2 className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>Configure your parameters to generate educational games</p>
              </div>
            </div>
          )}
        </motion.div>
      </div>

      {/* Game Ideas Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-gradient-to-r from-rose-50 to-pink-50 rounded-2xl p-6 border border-rose-200"
      >
        <h3 className="text-lg font-semibold text-slate-800 mb-4">
          🎮 Popular Game Ideas for Multi-Grade Classrooms
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <h4 className="font-medium text-slate-800 mb-2">Quick Games (5-10 min)</h4>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Vocabulary pictionary</li>
              <li>• Math fact relay races</li>
              <li>• Geography pointing games</li>
              <li>• Science true/false</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-slate-800 mb-2">Team Games (15-25 min)</h4>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Subject-based treasure hunts</li>
              <li>• Story building circles</li>
              <li>• Problem-solving challenges</li>
              <li>• Creative drama activities</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-slate-800 mb-2">Review Games (20-30 min)</h4>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Classroom quiz shows</li>
              <li>• Board game adaptations</li>
              <li>• Memory matching games</li>
              <li>• Role-playing scenarios</li>
            </ul>
          </div>
        </div>
      </motion.div>
    </div>
  );
};