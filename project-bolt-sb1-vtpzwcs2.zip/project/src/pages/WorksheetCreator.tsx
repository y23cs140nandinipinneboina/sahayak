import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Image, Upload, FileText, Users, Download, Eye } from 'lucide-react';

export const WorksheetCreator: React.FC = () => {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [worksheets, setWorksheets] = useState<any[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUploadedImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const generateWorksheets = async () => {
    setIsProcessing(true);
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Mock generated worksheets
    const mockWorksheets = [
      {
        id: 1,
        title: 'Grade 1-2: Basic Recognition',
        description: 'Simple matching and identification exercises',
        difficulty: 'Easy',
        questions: 8,
        timeEstimate: '15 min'
      },
      {
        id: 2,
        title: 'Grade 3-4: Understanding & Application',
        description: 'Fill in the blanks and short answer questions',
        difficulty: 'Medium',
        questions: 12,
        timeEstimate: '25 min'
      },
      {
        id: 3,
        title: 'Grade 5: Advanced Analysis',
        description: 'Critical thinking and detailed explanations',
        difficulty: 'Hard',
        questions: 10,
        timeEstimate: '30 min'
      }
    ];
    
    setWorksheets(mockWorksheets);
    setIsProcessing(false);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-800';
      case 'Medium': return 'bg-yellow-100 text-yellow-800';
      case 'Hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-blue-100 rounded-2xl">
            <Image className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-slate-800 mb-2">
          Smart Worksheet Creator
        </h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Upload textbook pages and get differentiated worksheets for multiple grade levels
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upload Section */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          {/* Image Upload */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center">
              <Upload className="w-5 h-5 mr-2 text-blue-500" />
              Upload Textbook Page
            </h2>
            
            <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center hover:border-blue-400 transition-colors">
              {uploadedImage ? (
                <div className="space-y-4">
                  <img
                    src={uploadedImage}
                    alt="Uploaded textbook page"
                    className="max-w-full h-48 object-contain mx-auto rounded-lg"
                  />
                  <div className="flex justify-center space-x-3">
                    <label className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 cursor-pointer transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                      Replace Image
                    </label>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto">
                    <Image className="w-8 h-8 text-slate-400" />
                  </div>
                  <div>
                    <p className="text-slate-600 mb-2">
                      Drop your textbook page here or click to browse
                    </p>
                    <p className="text-sm text-slate-400">
                      Supports JPG, PNG, PDF pages
                    </p>
                  </div>
                  <label className="inline-block px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 cursor-pointer transition-colors">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                    Choose File
                  </label>
                </div>
              )}
            </div>
          </div>

          {/* Generate Button */}
          {uploadedImage && (
            <button
              onClick={generateWorksheets}
              disabled={isProcessing}
              className="w-full py-4 px-6 bg-blue-500 text-white rounded-xl font-semibold hover:bg-blue-600 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                  Analyzing content and generating worksheets...
                </>
              ) : (
                <>
                  <FileText className="w-5 h-5 mr-2" />
                  Generate Differentiated Worksheets
                </>
              )}
            </button>
          )}
        </motion.div>

        {/* Generated Worksheets */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
        >
          <h2 className="text-xl font-semibold text-slate-800 mb-6 flex items-center">
            <Users className="w-5 h-5 mr-2 text-blue-500" />
            Generated Worksheets
          </h2>

          <div className="space-y-4">
            {worksheets.length > 0 ? (
              worksheets.map((worksheet) => (
                <div
                  key={worksheet.id}
                  className="border border-slate-200 rounded-xl p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-800 mb-1">
                        {worksheet.title}
                      </h3>
                      <p className="text-sm text-slate-600 mb-2">
                        {worksheet.description}
                      </p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(worksheet.difficulty)}`}>
                      {worksheet.difficulty}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm text-slate-500 mb-3">
                    <span>{worksheet.questions} questions</span>
                    <span>{worksheet.timeEstimate}</span>
                  </div>

                  <div className="flex space-x-2">
                    <button className="flex-1 py-2 px-3 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors flex items-center justify-center text-sm">
                      <Eye className="w-4 h-4 mr-1" />
                      Preview
                    </button>
                    <button className="flex-1 py-2 px-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors flex items-center justify-center text-sm">
                      <Download className="w-4 h-4 mr-1" />
                      Download
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-slate-400">
                <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>Upload a textbook page to generate worksheets</p>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Features Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-200"
      >
        <h3 className="text-lg font-semibold text-slate-800 mb-4">
          How It Works:
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Upload className="w-6 h-6 text-purple-600" />
            </div>
            <h4 className="font-medium text-slate-800 mb-2">1. Upload</h4>
            <p className="text-sm text-slate-600">
              Take a photo or upload a textbook page, worksheet, or any educational content
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <Image className="w-6 h-6 text-purple-600" />
            </div>
            <h4 className="font-medium text-slate-800 mb-2">2. AI Analysis</h4>
            <p className="text-sm text-slate-600">
              Our AI reads and understands the content, identifying key concepts and learning objectives
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3">
              <FileText className="w-6 h-6 text-purple-600" />
            </div>
            <h4 className="font-medium text-slate-800 mb-2">3. Generate</h4>
            <p className="text-sm text-slate-600">
              Get multiple worksheet versions tailored for different grade levels in your classroom
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};