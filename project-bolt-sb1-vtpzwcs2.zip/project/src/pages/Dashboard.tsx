import React from 'react';
import { motion } from 'framer-motion';
import { FeatureCard } from '../components/FeatureCard';
import {
  FileText,
  Image,
  HelpCircle,
  Palette,
  Mic,
  Calendar,
  Gamepad2,
  Users,
  TrendingUp,
  Clock,
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const features = [
    {
      title: 'Content Generator',
      description: 'Create hyper-local, culturally relevant content in your local language. Generate stories, examples, and explanations that resonate with your students.',
      icon: FileText,
      link: '/content-generator',
      gradient: 'bg-gradient-to-br from-orange-50 to-red-50',
      emoji: '📝',
    },
    {
      title: 'Worksheet Creator',
      description: 'Upload textbook pages and instantly generate differentiated worksheets for multiple grade levels in your classroom.',
      icon: Image,
      link: '/worksheet-creator',
      gradient: 'bg-gradient-to-br from-blue-50 to-indigo-50',
      emoji: '📄',
    },
    {
      title: 'Knowledge Base',
      description: 'Get instant, simple explanations for complex student questions with easy-to-understand analogies in your local language.',
      icon: HelpCircle,
      link: '/knowledge-base',
      gradient: 'bg-gradient-to-br from-green-50 to-emerald-50',
      emoji: '💡',
    },
    {
      title: 'Visual Aids',
      description: 'Generate simple line drawings and charts that you can easily replicate on your blackboard to explain complex concepts.',
      icon: Palette,
      link: '/visual-aids',
      gradient: 'bg-gradient-to-br from-purple-50 to-pink-50',
      emoji: '🎨',
    },
    {
      title: 'Audio Assessment',
      description: 'Conduct reading assessments using AI-powered speech recognition to track student progress and identify areas for improvement.',
      icon: Mic,
      link: '/audio-assessment',
      gradient: 'bg-gradient-to-br from-yellow-50 to-orange-50',
      emoji: '🎤',
    },
    {
      title: 'Lesson Planner',
      description: 'Create structured weekly lesson plans with activities and timelines that save you valuable preparation time.',
      icon: Calendar,
      link: '/lesson-planner',
      gradient: 'bg-gradient-to-br from-teal-50 to-cyan-50',
      emoji: '📅',
    },
    {
      title: 'Game Generator',
      description: 'Generate educational games and activities on-the-fly to make learning fun and engaging for all grade levels.',
      icon: Gamepad2,
      link: '/game-generator',
      gradient: 'bg-gradient-to-br from-rose-50 to-pink-50',
      emoji: '🎮',
    },
  ];

  const stats = [
    { label: 'Teachers Helped', value: '1,200+', icon: Users },
    { label: 'Content Generated', value: '5,000+', icon: FileText },
    { label: 'Student Improvement', value: '85%', icon: TrendingUp },
    { label: 'Time Saved', value: '3 hrs/day', icon: Clock },
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center py-12 px-6 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-3xl text-white shadow-2xl"
      >
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          Welcome to Sahayak 🙏
        </h1>
        <p className="text-xl md:text-2xl mb-6 text-white/90">
          Your AI-powered teaching companion for multi-grade classrooms
        </p>
        <p className="text-lg text-white/80 max-w-3xl mx-auto leading-relaxed">
          Empowering teachers with intelligent tools to create localized content, 
          differentiated materials, and engaging learning experiences that save time 
          and amplify your impact.
        </p>
      </motion.div>

      {/* Stats Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
      >
        {stats.map((stat, index) => (
          <div
            key={stat.label}
            className="bg-white rounded-2xl p-6 text-center shadow-sm border border-slate-200"
          >
            <stat.icon className="w-8 h-8 text-primary-500 mx-auto mb-3" />
            <div className="text-2xl font-bold text-slate-800 mb-1">
              {stat.value}
            </div>
            <div className="text-sm text-slate-600">{stat.label}</div>
          </div>
        ))}
      </motion.div>

      {/* Features Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6"
      >
        {features.map((feature, index) => (
          <motion.div
            key={feature.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index }}
          >
            <FeatureCard {...feature} />
          </motion.div>
        ))}
      </motion.div>

      {/* Quick Tips Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-gradient-to-r from-accent-50 to-green-50 rounded-2xl p-8 border border-accent-200"
      >
        <h2 className="text-2xl font-bold text-slate-800 mb-4 flex items-center">
          <span className="mr-3">💡</span>
          Quick Tips for Success
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <span className="text-accent-500 font-bold">1.</span>
              <p className="text-slate-700">
                Start with the Content Generator to create culturally relevant examples for your lessons.
              </p>
            </div>
            <div className="flex items-start space-x-3">
              <span className="text-accent-500 font-bold">2.</span>
              <p className="text-slate-700">
                Use the Worksheet Creator to adapt textbook content for different grade levels.
              </p>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <span className="text-accent-500 font-bold">3.</span>
              <p className="text-slate-700">
                Leverage the Knowledge Base for quick explanations during class discussions.
              </p>
            </div>
            <div className="flex items-start space-x-3">
              <span className="text-accent-500 font-bold">4.</span>
              <p className="text-slate-700">
                Plan your week efficiently using the AI-powered Lesson Planner.
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};