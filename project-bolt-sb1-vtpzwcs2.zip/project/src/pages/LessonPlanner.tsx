import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, BookOpen, Users, Target, Plus, Download } from 'lucide-react';

interface LessonPlan {
  id: number;
  title: string;
  subject: string;
  grade: string;
  duration: string;
  objectives: string[];
  activities: Activity[];
  materials: string[];
}

interface Activity {
  name: string;
  duration: number;
  type: 'introduction' | 'teaching' | 'practice' | 'assessment';
  description: string;
}

export const LessonPlanner: React.FC = () => {
  const [subject, setSubject] = useState('');
  const [topic, setTopic] = useState('');
  const [grades, setGrades] = useState<string[]>([]);
  const [duration, setDuration] = useState('60');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedPlan, setGeneratedPlan] = useState<LessonPlan | null>(null);

  const subjects = [
    'Mathematics', 'Science', 'English', 'Hindi', 'Social Studies', 
    'Environmental Studies', 'Art & Craft', 'Physical Education'
  ];

  const gradeOptions = ['1', '2', '3', '4', '5', '6', '7', '8'];

  const mockLessonPlan: LessonPlan = {
    id: 1,
    title: 'Understanding Fractions',
    subject: 'Mathematics',
    grade: '3-4',
    duration: '60 minutes',
    objectives: [
      'Students will understand what fractions represent',
      'Students will identify parts of a whole',
      'Students will compare simple fractions'
    ],
    activities: [
      {
        name: 'Warm-up Review',
        duration: 10,
        type: 'introduction',
        description: 'Quick review of whole numbers and parts using local examples (roti pieces, orange segments)'
      },
      {
        name: 'Fraction Introduction',
        duration: 20,
        type: 'teaching',
        description: 'Introduce fractions using real objects - cut fruits, divide chapati, share sweets among students'
      },
      {
        name: 'Hands-on Practice',
        duration: 20,
        type: 'practice',
        description: 'Students work in groups with paper circles, rectangles. Draw and shade fractions'
      },
      {
        name: 'Quick Assessment',
        duration: 10,
        type: 'assessment',
        description: 'Students identify fractions from visual representations on blackboard'
      }
    ],
    materials: [
      'Chart paper circles and rectangles',
      'Colored chalk/markers',
      'Real fruits for demonstration',
      'Student notebooks',
      'Blackboard'
    ]
  };

  const handleGradeSelection = (grade: string) => {
    setGrades(prev => 
      prev.includes(grade) 
        ? prev.filter(g => g !== grade)
        : [...prev, grade]
    );
  };

  const generateLessonPlan = async () => {
    setIsGenerating(true);
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    setGeneratedPlan(mockLessonPlan);
    setIsGenerating(false);
  };

  const getActivityColor = (type: Activity['type']) => {
    switch (type) {
      case 'introduction': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'teaching': return 'bg-green-100 text-green-800 border-green-200';
      case 'practice': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'assessment': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-teal-100 rounded-2xl">
            <Calendar className="w-8 h-8 text-teal-600" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-slate-800 mb-2">
          AI Lesson Planner
        </h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Create structured, time-efficient lesson plans tailored for multi-grade classrooms
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Panel */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
        >
          <h2 className="text-xl font-semibold text-slate-800 mb-6 flex items-center">
            <Plus className="w-5 h-5 mr-2 text-teal-500" />
            Plan Parameters
          </h2>

          <div className="space-y-6">
            {/* Subject Selection */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                <BookOpen className="w-4 h-4 inline mr-2" />
                Subject
              </label>
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
              >
                <option value="">Select Subject</option>
                {subjects.map((subj) => (
                  <option key={subj} value={subj}>{subj}</option>
                ))}
              </select>
            </div>

            {/* Topic Input */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                <Target className="w-4 h-4 inline mr-2" />
                Topic/Lesson Title
              </label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., Introduction to Fractions"
                className="w-full p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
              />
            </div>

            {/* Grade Selection */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                <Users className="w-4 h-4 inline mr-2" />
                Target Grades
              </label>
              <div className="grid grid-cols-4 gap-2">
                {gradeOptions.map((grade) => (
                  <button
                    key={grade}
                    onClick={() => handleGradeSelection(grade)}
                    className={`p-2 rounded-lg border-2 transition-colors text-sm font-medium ${
                      grades.includes(grade)
                        ? 'border-teal-500 bg-teal-50 text-teal-700'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    Grade {grade}
                  </button>
                ))}
              </div>
            </div>

            {/* Duration */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">
                <Clock className="w-4 h-4 inline mr-2" />
                Lesson Duration
              </label>
              <select
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full p-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
              >
                <option value="30">30 minutes</option>
                <option value="45">45 minutes</option>
                <option value="60">60 minutes</option>
                <option value="90">90 minutes</option>
              </select>
            </div>

            {/* Generate Button */}
            <button
              onClick={generateLessonPlan}
              disabled={!subject || !topic || grades.length === 0 || isGenerating}
              className="w-full py-3 px-4 bg-teal-500 text-white rounded-xl font-semibold hover:bg-teal-600 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              {isGenerating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Creating Lesson Plan...
                </>
              ) : (
                <>
                  <Calendar className="w-5 h-5 mr-2" />
                  Generate Plan
                </>
              )}
            </button>
          </div>
        </motion.div>

        {/* Generated Plan */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-2 space-y-6"
        >
          {generatedPlan ? (
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-slate-800">
                  Generated Lesson Plan
                </h2>
                <button className="px-4 py-2 bg-teal-500 text-white rounded-lg hover:bg-teal-600 transition-colors flex items-center text-sm">
                  <Download className="w-4 h-4 mr-1" />
                  Download
                </button>
              </div>

              {/* Plan Header */}
              <div className="bg-teal-50 rounded-xl p-4 mb-6 border border-teal-200">
                <h3 className="text-lg font-bold text-slate-800 mb-2">{generatedPlan.title}</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-slate-600">Subject:</span>
                    <div className="font-medium text-slate-800">{generatedPlan.subject}</div>
                  </div>
                  <div>
                    <span className="text-slate-600">Grade:</span>
                    <div className="font-medium text-slate-800">{generatedPlan.grade}</div>
                  </div>
                  <div>
                    <span className="text-slate-600">Duration:</span>
                    <div className="font-medium text-slate-800">{generatedPlan.duration}</div>
                  </div>
                  <div>
                    <span className="text-slate-600">Activities:</span>
                    <div className="font-medium text-slate-800">{generatedPlan.activities.length}</div>
                  </div>
                </div>
              </div>

              {/* Learning Objectives */}
              <div className="mb-6">
                <h4 className="text-lg font-semibold text-slate-800 mb-3">Learning Objectives</h4>
                <ul className="space-y-2">
                  {generatedPlan.objectives.map((objective, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-teal-500 mr-2">•</span>
                      <span className="text-slate-700">{objective}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Activities Timeline */}
              <div className="mb-6">
                <h4 className="text-lg font-semibold text-slate-800 mb-3">Activities Timeline</h4>
                <div className="space-y-4">
                  {generatedPlan.activities.map((activity, index) => (
                    <div key={index} className={`p-4 rounded-xl border ${getActivityColor(activity.type)}`}>
                      <div className="flex items-center justify-between mb-2">
                        <h5 className="font-semibold">{activity.name}</h5>
                        <span className="text-sm font-medium">{activity.duration} min</span>
                      </div>
                      <p className="text-sm">{activity.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Materials Needed */}
              <div>
                <h4 className="text-lg font-semibold text-slate-800 mb-3">Materials Needed</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {generatedPlan.materials.map((material, index) => (
                    <div key={index} className="flex items-center p-2 bg-slate-50 rounded-lg">
                      <span className="text-slate-600 mr-2">✓</span>
                      <span className="text-slate-700 text-sm">{material}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
              <div className="text-center py-12 text-slate-400">
                <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>Fill in the parameters to generate your lesson plan</p>
              </div>
            </div>
          )}
        </motion.div>
      </div>

      {/* Tips Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-2xl p-6 border border-teal-200"
      >
        <h3 className="text-lg font-semibold text-slate-800 mb-4">
          💡 Planning Tips for Multi-Grade Classrooms
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-teal-600 mr-2">•</span>
              Start with activities that engage all grade levels simultaneously
            </p>
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-teal-600 mr-2">•</span>
              Include differentiated tasks within the same topic
            </p>
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-teal-600 mr-2">•</span>
              Use peer learning - older students can help younger ones
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-teal-600 mr-2">•</span>
              Plan for flexible grouping based on skill level
            </p>
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-teal-600 mr-2">•</span>
              Keep materials simple and locally available
            </p>
            <p className="text-sm text-slate-700 flex items-start">
              <span className="text-teal-600 mr-2">•</span>
              Build in assessment checkpoints throughout the lesson
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};