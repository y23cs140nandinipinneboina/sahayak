import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Palette, Image, Download, Lightbulb, Pencil, Shapes } from 'lucide-react';

export const VisualAids: React.FC = () => {
  const [description, setDescription] = useState('');
  const [visualType, setVisualType] = useState('diagram');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<any[]>([]);

  const visualTypes = [
    { value: 'diagram', label: 'Simple Diagram', icon: '📊', description: 'Flow charts, process diagrams' },
    { value: 'drawing', label: 'Line Drawing', icon: '✏️', description: 'Simple illustrations, sketches' },
    { value: 'chart', label: 'Educational Chart', icon: '📈', description: 'Graphs, tables, comparisons' },
    { value: 'map', label: 'Simple Map', icon: '🗺️', description: 'Geographic layouts, directions' },
    { value: 'timeline', label: 'Timeline', icon: '📅', description: 'Historical sequences, schedules' },
    { value: 'shapes', label: 'Geometric Shapes', icon: '🔺', description: 'Mathematical figures, patterns' },
  ];

  const exampleRequests = [
    "Water cycle with labeled arrows and stages",
    "Human digestive system with simple organs",
    "Solar system with planets in order",
    "Plant life cycle from seed to flower",
    "Food chain in a forest ecosystem",
    "Parts of a flower with labels"
  ];

  const mockGeneratedImages = [
    {
      id: 1,
      title: "Water Cycle Diagram",
      description: "Simple line drawing showing evaporation, condensation, and precipitation",
      downloadUrl: "#",
      complexity: "Simple"
    },
    {
      id: 2,
      title: "Blackboard Version",
      description: "Simplified version optimized for drawing on blackboard",
      downloadUrl: "#",
      complexity: "Very Simple"
    }
  ];

  const handleGenerate = async () => {
    setIsGenerating(true);
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    setGeneratedImages(mockGeneratedImages);
    setIsGenerating(false);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-purple-100 rounded-2xl">
            <Palette className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-slate-800 mb-2">
          Visual Aids Generator
        </h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Create simple, blackboard-friendly visual aids to explain complex concepts
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Panel */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-2 space-y-6"
        >
          {/* Visual Type Selection */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center">
              <Shapes className="w-5 h-5 mr-2 text-purple-500" />
              Choose Visual Type
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {visualTypes.map((type) => (
                <button
                  key={type.value}
                  onClick={() => setVisualType(type.value)}
                  className={`p-4 rounded-xl border-2 transition-colors text-left ${
                    visualType === type.value
                      ? 'border-purple-500 bg-purple-50'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="text-2xl mb-2">{type.icon}</div>
                  <div className="font-medium text-sm text-slate-800 mb-1">
                    {type.label}
                  </div>
                  <div className="text-xs text-slate-600">
                    {type.description}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Description Input */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center">
              <Pencil className="w-5 h-5 mr-2 text-purple-500" />
              Describe Your Visual Aid
            </h2>
            
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what you want to draw on the blackboard..."
              className="w-full p-4 border border-slate-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 h-32 resize-none mb-4"
            />

            <button
              onClick={handleGenerate}
              disabled={!description.trim() || isGenerating}
              className="w-full py-3 px-4 bg-purple-500 text-white rounded-xl font-semibold hover:bg-purple-600 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            >
              {isGenerating ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Creating Visual Aid...
                </>
              ) : (
                <>
                  <Image className="w-5 h-5 mr-2" />
                  Generate Visual Aid
                </>
              )}
            </button>
          </div>

          {/* Generated Images */}
          {generatedImages.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
            >
              <h2 className="text-xl font-semibold text-slate-800 mb-4">
                Generated Visual Aids
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {generatedImages.map((img) => (
                  <div key={img.id} className="border border-slate-200 rounded-xl p-4">
                    <div className="bg-slate-100 rounded-lg h-48 flex items-center justify-center mb-4">
                      <div className="text-center text-slate-500">
                        <Image className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">Generated visual will appear here</p>
                      </div>
                    </div>
                    
                    <h3 className="font-semibold text-slate-800 mb-2">{img.title}</h3>
                    <p className="text-sm text-slate-600 mb-3">{img.description}</p>
                    
                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        img.complexity === 'Simple' ? 'bg-green-100 text-green-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {img.complexity}
                      </span>
                      <button className="px-3 py-1 bg-purple-500 text-white rounded-lg text-sm hover:bg-purple-600 transition-colors flex items-center">
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </motion.div>

        {/* Sidebar */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="space-y-6"
        >
          {/* Example Requests */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
              <Lightbulb className="w-5 h-5 mr-2 text-yellow-500" />
              Example Requests
            </h3>
            
            <div className="space-y-2">
              {exampleRequests.map((request, index) => (
                <button
                  key={index}
                  onClick={() => setDescription(request)}
                  className="w-full p-3 text-left text-sm text-slate-600 hover:text-slate-800 hover:bg-slate-50 rounded-lg transition-colors border border-transparent hover:border-slate-200"
                >
                  {request}
                </button>
              ))}
            </div>
          </div>

          {/* Features */}
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-6 border border-purple-200">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">
              🎨 Perfect for Blackboards
            </h3>
            <ul className="text-sm text-slate-700 space-y-2">
              <li className="flex items-start">
                <span className="text-purple-600 mr-2">✓</span>
                Simple line drawings that are easy to replicate
              </li>
              <li className="flex items-start">
                <span className="text-purple-600 mr-2">✓</span>
                Clear labels and minimal text
              </li>
              <li className="flex items-start">
                <span className="text-purple-600 mr-2">✓</span>
                Optimized for chalk or marker drawing
              </li>
              <li className="flex items-start">
                <span className="text-purple-600 mr-2">✓</span>
                Multiple complexity levels available
              </li>
            </ul>
          </div>

          {/* Tips */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-4 border border-blue-200">
            <h4 className="font-semibold text-slate-800 mb-2">💡 Tips</h4>
            <ul className="text-sm text-slate-700 space-y-1">
              <li>• Be specific about what you want to show</li>
              <li>• Mention if you want labels or arrows</li>
              <li>• Request "simple" or "blackboard-friendly"</li>
              <li>• Ask for step-by-step versions</li>
            </ul>
          </div>
        </motion.div>
      </div>
    </div>
  );
};