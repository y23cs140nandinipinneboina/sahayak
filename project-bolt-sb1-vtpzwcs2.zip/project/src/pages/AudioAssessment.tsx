import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mic, MicOff, Play, Pause, RotateCcw, TrendingUp, User, CheckCircle } from 'lucide-react';

interface Student {
  id: number;
  name: string;
  grade: number;
  lastAssessment: string;
  readingLevel: string;
  progress: number;
}

export const AudioAssessment: React.FC = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [assessmentText, setAssessmentText] = useState('');
  const [recordingTime, setRecordingTime] = useState(0);

  const students: Student[] = [
    {
      id: 1,
      name: 'Aarav Sharma',
      grade: 3,
      lastAssessment: '2 days ago',
      readingLevel: 'Beginner',
      progress: 65
    },
    {
      id: 2,
      name: 'Priya Patel',
      grade: 4,
      lastAssessment: '1 week ago',
      readingLevel: 'Intermediate',
      progress: 82
    },
    {
      id: 3,
      name: 'Rahul Kumar',
      grade: 2,
      lastAssessment: '3 days ago',
      readingLevel: 'Beginner',
      progress: 45
    },
    {
      id: 4,
      name: 'Meera Singh',
      grade: 5,
      lastAssessment: '1 day ago',
      readingLevel: 'Advanced',
      progress: 94
    }
  ];

  const sampleTexts = [
    {
      grade: '1-2',
      text: 'The cat sat on the mat. It was a big, fat cat. The cat was happy.',
      words: 15
    },
    {
      grade: '3-4',
      text: 'Once upon a time, there was a little bird who lived in a beautiful tree. Every morning, the bird would sing sweet songs that made all the animals in the forest happy.',
      words: 32
    },
    {
      grade: '4-5',
      text: 'The water cycle is an important process in nature. Water evaporates from rivers and oceans, rises into the sky as clouds, and then falls back to earth as rain.',
      words: 29
    }
  ];

  const getProgressColor = (progress: number) => {
    if (progress >= 80) return 'text-green-600 bg-green-100';
    if (progress >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const startRecording = () => {
    setIsRecording(true);
    // Start recording logic would go here
  };

  const stopRecording = () => {
    setIsRecording(false);
    // Stop recording and process audio
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-yellow-100 rounded-2xl">
            <Mic className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-slate-800 mb-2">
          Audio Reading Assessment
        </h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Track student reading progress with AI-powered speech analysis
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Student List */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200"
        >
          <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center">
            <User className="w-5 h-5 mr-2 text-blue-500" />
            Students
          </h2>
          
          <div className="space-y-3">
            {students.map((student) => (
              <button
                key={student.id}
                onClick={() => setCurrentStudent(student)}
                className={`w-full p-4 rounded-xl border-2 transition-colors text-left ${
                  currentStudent?.id === student.id
                    ? 'border-yellow-500 bg-yellow-50'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-medium text-slate-800">{student.name}</h3>
                    <p className="text-sm text-slate-600">Grade {student.grade}</p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getProgressColor(student.progress)}`}>
                    {student.progress}%
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-500">{student.readingLevel}</span>
                  <span className="text-slate-400">{student.lastAssessment}</span>
                </div>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Assessment Panel */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:col-span-2 space-y-6"
        >
          {/* Recording Interface */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h2 className="text-xl font-semibold text-slate-800 mb-4">
              Reading Assessment
            </h2>

            {currentStudent ? (
              <div className="space-y-6">
                {/* Student Info */}
                <div className="bg-slate-50 rounded-xl p-4">
                  <h3 className="font-semibold text-slate-800 mb-2">
                    Assessing: {currentStudent.name}
                  </h3>
                  <div className="flex items-center space-x-4 text-sm text-slate-600">
                    <span>Grade {currentStudent.grade}</span>
                    <span>•</span>
                    <span>{currentStudent.readingLevel} Level</span>
                    <span>•</span>
                    <span>Current Progress: {currentStudent.progress}%</span>
                  </div>
                </div>

                {/* Reading Text Selection */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-3">
                    Choose Reading Text
                  </label>
                  <div className="space-y-2">
                    {sampleTexts.map((sample, index) => (
                      <button
                        key={index}
                        onClick={() => setAssessmentText(sample.text)}
                        className={`w-full p-3 rounded-lg border-2 transition-colors text-left ${
                          assessmentText === sample.text
                            ? 'border-yellow-500 bg-yellow-50'
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium text-sm">Grade {sample.grade}</span>
                          <span className="text-xs text-slate-500">{sample.words} words</span>
                        </div>
                        <p className="text-sm text-slate-700 line-clamp-2">{sample.text}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Reading Text Display */}
                {assessmentText && (
                  <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
                    <h4 className="font-medium text-slate-800 mb-2">Reading Text:</h4>
                    <p className="text-slate-700 leading-relaxed text-lg">
                      {assessmentText}
                    </p>
                  </div>
                )}

                {/* Recording Controls */}
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-4 mb-4">
                    <button
                      onClick={isRecording ? stopRecording : startRecording}
                      className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors ${
                        isRecording
                          ? 'bg-red-500 hover:bg-red-600'
                          : 'bg-yellow-500 hover:bg-yellow-600'
                      }`}
                    >
                      {isRecording ? (
                        <MicOff className="w-8 h-8 text-white" />
                      ) : (
                        <Mic className="w-8 h-8 text-white" />
                      )}
                    </button>
                  </div>
                  
                  <p className="text-sm text-slate-600 mb-2">
                    {isRecording ? 'Recording...' : 'Click to start recording'}
                  </p>
                  
                  {isRecording && (
                    <div className="text-lg font-mono text-slate-800">
                      {Math.floor(recordingTime / 60)}:{(recordingTime % 60).toString().padStart(2, '0')}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-slate-400">
                <User className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>Select a student to begin assessment</p>
              </div>
            )}
          </div>

          {/* Results Panel */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <h2 className="text-xl font-semibold text-slate-800 mb-4 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-green-500" />
              Assessment Results
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-green-50 rounded-xl p-4 border border-green-200">
                <div className="flex items-center mb-2">
                  <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                  <span className="font-medium text-green-800">Accuracy</span>
                </div>
                <div className="text-2xl font-bold text-green-700">87%</div>
                <p className="text-sm text-green-600">Word recognition</p>
              </div>
              
              <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
                <div className="flex items-center mb-2">
                  <Play className="w-5 h-5 text-blue-600 mr-2" />
                  <span className="font-medium text-blue-800">Fluency</span>
                </div>
                <div className="text-2xl font-bold text-blue-700">92 WPM</div>
                <p className="text-sm text-blue-600">Words per minute</p>
              </div>
              
              <div className="bg-purple-50 rounded-xl p-4 border border-purple-200">
                <div className="flex items-center mb-2">
                  <Mic className="w-5 h-5 text-purple-600 mr-2" />
                  <span className="font-medium text-purple-800">Expression</span>
                </div>
                <div className="text-2xl font-bold text-purple-700">Good</div>
                <p className="text-sm text-purple-600">Intonation & pace</p>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-slate-50 rounded-xl">
              <h4 className="font-medium text-slate-800 mb-2">AI Feedback:</h4>
              <p className="text-sm text-slate-700">
                Great improvement in reading fluency! The student showed good word recognition 
                and proper pacing. Areas for focus: pronunciation of complex words and 
                maintaining consistent volume throughout the passage.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};