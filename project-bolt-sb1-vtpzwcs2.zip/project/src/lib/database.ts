import { supabase } from './supabase';
import type { Teacher, Student, GeneratedContent, AudioAssessment, LessonPlan } from './supabase';

// Authentication functions
export const signUp = async (email: string, password: string, userData: Partial<Teacher>) => {
  try {
    console.log('Starting signup process...');
    
    // First, create the user account
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    });
    
    if (authError) {
      console.error('Auth signup error:', authError);
      throw authError;
    }
    
    if (!authData.user) {
      throw new Error('User creation failed - no user returned');
    }
    
    console.log('User created successfully:', authData.user.id);
    
    // Wait for the session to be established
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Ensure we have a valid session before proceeding
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    
    if (sessionError || !session) {
      console.error('Session error:', sessionError);
      throw new Error('Failed to establish user session');
    }
    
    console.log('Session established, creating teacher profile...');
    
    // Now create the teacher profile with the authenticated session
    const teacherProfile = {
      id: authData.user.id,
      email: email,
      name: userData.name || '',
      school_name: userData.school_name || null,
      grades_taught: userData.grades_taught || [],
      preferred_language: userData.preferred_language || 'english'
    };
    
    const { data: profileData, error: profileError } = await supabase
      .from('teachers')
      .insert([teacherProfile])
      .select()
      .single();
    
    if (profileError) {
      console.error('Profile creation error:', profileError);
      throw new Error(`Failed to create teacher profile: ${profileError.message}`);
    }
    
    console.log('Teacher profile created successfully:', profileData);
    
    return {
      user: authData.user,
      session: authData.session,
      profile: profileData
    };
  } catch (error) {
    console.error('Error in signUp:', error);
    throw error;
  }
};

export const signIn = async (email: string, password: string) => {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (error) throw error;
    console.log('Sign in successful:', data.user?.id);
    return data;
  } catch (error) {
    console.error('Error in signIn:', error);
    throw error;
  }
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};

export const getCurrentUser = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

// Student authentication functions
export const signUpStudent = async (email: string, password: string, studentData: Partial<Student>) => {
  try {
    console.log('Starting student signup process...');
    
    // First, create the user account
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    });
    
    if (authError) {
      console.error('Student auth signup error:', authError);
      throw authError;
    }
    
    if (!authData.user) {
      throw new Error('Student user creation failed - no user returned');
    }
    
    console.log('Student user created successfully:', authData.user.id);
    
    // Wait for the session to be established
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Update the existing student record with authentication info
    if (studentData.id) {
      const { data: updatedStudent, error: updateError } = await supabase
        .from('students')
        .update({
          email: email,
          is_authenticated: true,
          updated_at: new Date().toISOString()
        })
        .eq('id', studentData.id)
        .select()
        .single();
      
      if (updateError) {
        console.error('Student profile update error:', updateError);
        throw new Error(`Failed to update student profile: ${updateError.message}`);
      }
      
      console.log('Student profile updated successfully:', updatedStudent);
      return {
        user: authData.user,
        session: authData.session,
        student: updatedStudent
      };
    }
    
    return {
      user: authData.user,
      session: authData.session
    };
  } catch (error) {
    console.error('Error in signUpStudent:', error);
    throw error;
  }
};

export const signInStudent = async (email: string, password: string) => {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (error) throw error;
    
    // Get the student profile
    const { data: student, error: studentError } = await supabase
      .from('students')
      .select('*')
      .eq('email', email)
      .single();
    
    if (studentError) {
      console.error('Error fetching student profile:', studentError);
    }
    
    console.log('Student sign in successful:', data.user?.id);
    return { ...data, student };
  } catch (error) {
    console.error('Error in signInStudent:', error);
    throw error;
  }
};

// Teacher functions
export const createTeacherProfile = async (teacherData: Omit<Teacher, 'created_at' | 'updated_at'>) => {
  try {
    console.log('Creating teacher profile:', teacherData);
    const { data, error } = await supabase
      .from('teachers')
      .insert([{
        ...teacherData,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }])
      .select()
      .single();
    
    if (error) {
      console.error('Error creating teacher profile:', error);
      throw error;
    }
    
    console.log('Teacher profile created successfully:', data);
    return data;
  } catch (error) {
    console.error('Error in createTeacherProfile:', error);
    throw error;
  }
};

export const getTeacherProfile = async (userId: string): Promise<Teacher | null> => {
  try {
    console.log('Fetching teacher profile for user:', userId);
    const { data, error } = await supabase
      .from('teachers')
      .select('*')
      .eq('id', userId);
    
    if (error) {
      console.error('Error fetching teacher profile:', error);
      throw error;
    }
    
    // Return the first profile if it exists, otherwise return null
    const profile = data && data.length > 0 ? data[0] : null;
    console.log('Teacher profile fetched:', profile);
    return profile;
  } catch (error) {
    console.error('Error in getTeacherProfile:', error);
    throw error;
  }
};

export const updateTeacherProfile = async (userId: string, updates: Partial<Teacher>) => {
  const { data, error } = await supabase
    .from('teachers')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', userId)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

// Student functions
export const createStudent = async (studentData: Omit<Student, 'id' | 'created_at' | 'updated_at'>) => {
  const { data, error } = await supabase
    .from('students')
    .insert([{
      ...studentData,
      student_code: studentData.student_code || `STU${Date.now()}`,
      is_authenticated: false
    }])
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const getStudentsByTeacher = async (teacherId: string) => {
  const { data, error } = await supabase
    .from('students')
    .select('*')
    .eq('teacher_id', teacherId)
    .order('name');
  
  if (error) throw error;
  return data;
};

export const getStudentProfile = async (studentId: string): Promise<Student | null> => {
  try {
    const { data, error } = await supabase
      .from('students')
      .select('*')
      .eq('id', studentId)
      .single();
    
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error fetching student profile:', error);
    return null;
  }
};

export const updateStudent = async (studentId: string, updates: Partial<Student>) => {
  const { data, error } = await supabase
    .from('students')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', studentId)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const deleteStudent = async (studentId: string) => {
  const { error } = await supabase
    .from('students')
    .delete()
    .eq('id', studentId);
  
  if (error) throw error;
};

// Content functions
export const saveGeneratedContent = async (contentData: Omit<GeneratedContent, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('generated_content')
    .insert([contentData])
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const getContentByTeacher = async (teacherId: string, contentType?: string) => {
  let query = supabase
    .from('generated_content')
    .select('*')
    .eq('teacher_id', teacherId);
  
  if (contentType) {
    query = query.eq('content_type', contentType);
  }
  
  const { data, error } = await query.order('created_at', { ascending: false });
  
  if (error) throw error;
  return data;
};

export const deleteContent = async (contentId: string) => {
  const { error } = await supabase
    .from('generated_content')
    .delete()
    .eq('id', contentId);
  
  if (error) throw error;
};

// Audio Assessment functions
export const saveAudioAssessment = async (assessmentData: Omit<AudioAssessment, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('audio_assessments')
    .insert([assessmentData])
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const getAssessmentsByStudent = async (studentId: string) => {
  const { data, error } = await supabase
    .from('audio_assessments')
    .select('*')
    .eq('student_id', studentId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data;
};

export const getAssessmentsByTeacher = async (teacherId: string) => {
  const { data, error } = await supabase
    .from('audio_assessments')
    .select(`
      *,
      students (
        name,
        grade
      )
    `)
    .eq('teacher_id', teacherId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data;
};

// Lesson Plan functions
export const saveLessonPlan = async (lessonData: Omit<LessonPlan, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('lesson_plans')
    .insert([lessonData])
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const getLessonPlansByTeacher = async (teacherId: string) => {
  const { data, error } = await supabase
    .from('lesson_plans')
    .select('*')
    .eq('teacher_id', teacherId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data;
};

export const updateLessonPlan = async (lessonId: string, updates: Partial<LessonPlan>) => {
  const { data, error } = await supabase
    .from('lesson_plans')
    .update(updates)
    .eq('id', lessonId)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const deleteLessonPlan = async (lessonId: string) => {
  const { error } = await supabase
    .from('lesson_plans')
    .delete()
    .eq('id', lessonId);
  
  if (error) throw error;
};

// File upload functions
export const uploadAudioFile = async (file: File, fileName: string) => {
  const { data, error } = await supabase.storage
    .from('audio-assessments')
    .upload(fileName, file);
  
  if (error) throw error;
  
  const { data: { publicUrl } } = supabase.storage
    .from('audio-assessments')
    .getPublicUrl(fileName);
  
  return publicUrl;
};

export const uploadImage = async (file: File, fileName: string, bucket: string = 'images') => {
  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(fileName, file);
  
  if (error) throw error;
  
  const { data: { publicUrl } } = supabase.storage
    .from(bucket)
    .getPublicUrl(fileName);
  
  return publicUrl;
};