import { generateContent } from './ai-services';

export interface GradingResult {
  totalScore: number;
  maxScore: number;
  percentage: number;
  feedback: string;
  questionResults: QuestionResult[];
}

export interface QuestionResult {
  questionNumber: number;
  studentAnswer: string;
  correctAnswer: string;
  isCorrect: boolean;
  partialCredit: number;
  feedback: string;
}

export const gradeWorksheet = async (
  worksheetImage: string,
  answerKey: string,
  subject: string,
  gradeLevel: string
): Promise<GradingResult> => {
  const apiKey = import.meta.env.VITE_GOOGLE_AI_API_KEY;
  
  if (!apiKey) {
    throw new Error('Google AI API key not configured');
  }

  const prompt = `
    You are an AI teacher assistant that grades student worksheets.
    
    Subject: ${subject}
    Grade Level: ${gradeLevel}
    
    Answer Key: ${answerKey}
    
    Please analyze the student's worksheet image and:
    1. Extract all visible answers from the student's work
    2. Compare with the answer key
    3. Provide scores and constructive feedback
    4. Be encouraging and specific about what the student did well
    5. Suggest areas for improvement
    
    Return a JSON response with this structure:
    {
      "totalScore": number,
      "maxScore": number,
      "percentage": number,
      "feedback": "Overall encouraging feedback",
      "questionResults": [
        {
          "questionNumber": number,
          "studentAnswer": "extracted answer",
          "correctAnswer": "from answer key",
          "isCorrect": boolean,
          "partialCredit": 0-1,
          "feedback": "specific feedback for this question"
        }
      ]
    }
    
    Be generous with partial credit for showing work or being close to correct.
    Focus on learning and improvement rather than just correctness.
  `;

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro-vision:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [
            {
              text: prompt
            },
            {
              inline_data: {
                mime_type: "image/jpeg",
                data: worksheetImage.split(',')[1] // Remove data:image/jpeg;base64, prefix
              }
            }
          ]
        }]
      })
    });

    if (!response.ok) {
      throw new Error('Failed to grade worksheet');
    }

    const data = await response.json();
    const content = data.candidates[0].content.parts[0].text;
    
    try {
      return JSON.parse(content);
    } catch {
      // If JSON parsing fails, return a default result
      return {
        totalScore: 0,
        maxScore: 10,
        percentage: 0,
        feedback: "I had trouble reading this worksheet. Please ensure the image is clear and try again.",
        questionResults: []
      };
    }
  } catch (error) {
    console.error('Error grading worksheet:', error);
    throw new Error('Failed to grade worksheet. Please try again.');
  }
};

export const extractTextFromImage = async (imageData: string): Promise<string> => {
  const apiKey = import.meta.env.VITE_GOOGLE_AI_API_KEY;
  
  if (!apiKey) {
    throw new Error('Google AI API key not configured');
  }

  const prompt = `
    Extract all text from this image. 
    Preserve the structure and formatting as much as possible.
    If this appears to be a worksheet or educational material, 
    clearly separate questions from answers.
  `;

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro-vision:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [
            {
              text: prompt
            },
            {
              inline_data: {
                mime_type: "image/jpeg",
                data: imageData.split(',')[1]
              }
            }
          ]
        }]
      })
    });

    if (!response.ok) {
      throw new Error('Failed to extract text');
    }

    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error('Error extracting text:', error);
    throw new Error('Failed to extract text from image. Please try again.');
  }
};