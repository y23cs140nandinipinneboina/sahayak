import { ref, push, onValue, off, update, remove } from 'firebase/database';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { realtimeDb, storage } from './firebase';

export interface SharedContent {
  id?: string;
  title: string;
  description: string;
  contentType: 'worksheet' | 'story' | 'visual_aid' | 'lesson_plan' | 'game';
  subject: string;
  gradeLevel: string;
  language: string;
  content: string;
  fileUrl?: string;
  authorName: string;
  schoolName?: string;
  upvotes: number;
  downloads: number;
  tags: string[];
  createdAt: number;
  updatedAt: number;
}

export interface ContentComment {
  id?: string;
  contentId: string;
  authorName: string;
  comment: string;
  timestamp: number;
}

// Content Sharing Functions
export const shareContent = async (content: Omit<SharedContent, 'id' | 'upvotes' | 'downloads' | 'createdAt' | 'updatedAt'>, file?: File) => {
  try {
    let fileUrl = '';
    
    if (file) {
      const fileRef = storageRef(storage, `shared-content/${Date.now()}_${file.name}`);
      const snapshot = await uploadBytes(fileRef, file);
      fileUrl = await getDownloadURL(snapshot.ref);
    }
    
    const contentData: Omit<SharedContent, 'id'> = {
      ...content,
      fileUrl,
      upvotes: 0,
      downloads: 0,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    
    const contentRef = ref(realtimeDb, 'shared-content');
    const newContentRef = push(contentRef);
    await update(newContentRef, contentData);
    
    return newContentRef.key;
  } catch (error) {
    console.error('Error sharing content:', error);
    throw error;
  }
};

export const getSharedContent = (callback: (content: SharedContent[]) => void) => {
  const contentRef = ref(realtimeDb, 'shared-content');
  
  onValue(contentRef, (snapshot) => {
    const data = snapshot.val();
    if (data) {
      const contentArray = Object.keys(data).map(key => ({
        id: key,
        ...data[key]
      })) as SharedContent[];
      
      // Sort by upvotes and recency
      contentArray.sort((a, b) => {
        const scoreA = a.upvotes * 2 + (Date.now() - a.createdAt) / (1000 * 60 * 60 * 24); // Decay over days
        const scoreB = b.upvotes * 2 + (Date.now() - b.createdAt) / (1000 * 60 * 60 * 24);
        return scoreB - scoreA;
      });
      
      callback(contentArray);
    } else {
      callback([]);
    }
  });
  
  return () => off(contentRef);
};

export const upvoteContent = async (contentId: string) => {
  try {
    const contentRef = ref(realtimeDb, `shared-content/${contentId}/upvotes`);
    const snapshot = await new Promise((resolve) => {
      onValue(contentRef, resolve, { onlyOnce: true });
    });
    
    const currentUpvotes = (snapshot as any).val() || 0;
    await update(ref(realtimeDb, `shared-content/${contentId}`), {
      upvotes: currentUpvotes + 1,
      updatedAt: Date.now()
    });
  } catch (error) {
    console.error('Error upvoting content:', error);
    throw error;
  }
};

export const downloadContent = async (contentId: string) => {
  try {
    const contentRef = ref(realtimeDb, `shared-content/${contentId}/downloads`);
    const snapshot = await new Promise((resolve) => {
      onValue(contentRef, resolve, { onlyOnce: true });
    });
    
    const currentDownloads = (snapshot as any).val() || 0;
    await update(ref(realtimeDb, `shared-content/${contentId}`), {
      downloads: currentDownloads + 1,
      updatedAt: Date.now()
    });
  } catch (error) {
    console.error('Error tracking download:', error);
    throw error;
  }
};

export const addComment = async (comment: Omit<ContentComment, 'id' | 'timestamp'>) => {
  try {
    const commentData = {
      ...comment,
      timestamp: Date.now()
    };
    
    const commentsRef = ref(realtimeDb, `comments/${comment.contentId}`);
    const newCommentRef = push(commentsRef);
    await update(newCommentRef, commentData);
    
    return newCommentRef.key;
  } catch (error) {
    console.error('Error adding comment:', error);
    throw error;
  }
};

export const getComments = (contentId: string, callback: (comments: ContentComment[]) => void) => {
  const commentsRef = ref(realtimeDb, `comments/${contentId}`);
  
  onValue(commentsRef, (snapshot) => {
    const data = snapshot.val();
    if (data) {
      const commentsArray = Object.keys(data).map(key => ({
        id: key,
        ...data[key]
      })) as ContentComment[];
      
      commentsArray.sort((a, b) => b.timestamp - a.timestamp);
      callback(commentsArray);
    } else {
      callback([]);
    }
  });
  
  return () => off(commentsRef);
};