import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Teacher {
  id: string;
  email: string;
  name: string;
  school_name?: string;
  grades_taught: number[];
  preferred_language: string;
  created_at: string;
  updated_at: string;
}

export interface Student {
  id: string;
  teacher_id: string;
  name: string;
  grade: number;
  reading_level: 'beginner' | 'intermediate' | 'advanced';
  progress_score: number;
  email?: string;
  is_authenticated: boolean;
  student_code?: string;
  parent_contact?: string;
  created_at: string;
  updated_at: string;
}

export interface GeneratedContent {
  id: string;
  teacher_id: string;
  title: string;
  content_type: 'story' | 'explanation' | 'worksheet' | 'visual_aid' | 'lesson_plan';
  content: string;
  subject: string;
  grade_levels: number[];
  language: string;
  created_at: string;
}

export interface AudioAssessment {
  id: string;
  student_id: string;
  teacher_id: string;
  audio_url: string;
  transcript: string;
  accuracy_score: number;
  fluency_score: number;
  words_per_minute: number;
  feedback: string;
  created_at: string;
}

export interface LessonPlan {
  id: string;
  teacher_id: string;
  title: string;
  subject: string;
  grade_levels: number[];
  duration_minutes: number;
  objectives: string[];
  activities: any[];
  materials: string[];
  created_at: string;
}

// Comprehensive Indian languages list
export const INDIAN_LANGUAGES = [
  { value: 'english', label: 'English', flag: '🇬🇧', native: 'English' },
  { value: 'hindi', label: 'Hindi', flag: '🇮🇳', native: 'हिंदी' },
  { value: 'bengali', label: 'Bengali', flag: '🇮🇳', native: 'বাংলা' },
  { value: 'telugu', label: 'Telugu', flag: '🇮🇳', native: 'తెలుగు' },
  { value: 'marathi', label: 'Marathi', flag: '🇮🇳', native: 'मराठी' },
  { value: 'tamil', label: 'Tamil', flag: '🇮🇳', native: 'தமிழ்' },
  { value: 'gujarati', label: 'Gujarati', flag: '🇮🇳', native: 'ગુજરાતી' },
  { value: 'urdu', label: 'Urdu', flag: '🇮🇳', native: 'اردو' },
  { value: 'kannada', label: 'Kannada', flag: '🇮🇳', native: 'ಕನ್ನಡ' },
  { value: 'odia', label: 'Odia', flag: '🇮🇳', native: 'ଓଡ଼ିଆ' },
  { value: 'punjabi', label: 'Punjabi', flag: '🇮🇳', native: 'ਪੰਜਾਬੀ' },
  { value: 'malayalam', label: 'Malayalam', flag: '🇮🇳', native: 'മലയാളം' },
  { value: 'assamese', label: 'Assamese', flag: '🇮🇳', native: 'অসমীয়া' },
  { value: 'maithili', label: 'Maithili', flag: '🇮🇳', native: 'मैथिली' },
  { value: 'santali', label: 'Santali', flag: '🇮🇳', native: 'ᱥᱟᱱᱛᱟᱲᱤ' },
  { value: 'kashmiri', label: 'Kashmiri', flag: '🇮🇳', native: 'कॉशुर' },
  { value: 'nepali', label: 'Nepali', flag: '🇮🇳', native: 'नेपाली' },
  { value: 'konkani', label: 'Konkani', flag: '🇮🇳', native: 'कोंकणी' },
  { value: 'sindhi', label: 'Sindhi', flag: '🇮🇳', native: 'سنڌي' },
  { value: 'dogri', label: 'Dogri', flag: '🇮🇳', native: 'डोगरी' },
  { value: 'manipuri', label: 'Manipuri', flag: '🇮🇳', native: 'মৈতৈলোন্' },
  { value: 'bodo', label: 'Bodo', flag: '🇮🇳', native: 'बर\'' },
  { value: 'santhali', label: 'Santhali', flag: '🇮🇳', native: 'ᱥᱟᱱᱛᱟᱲᱤ' },
];