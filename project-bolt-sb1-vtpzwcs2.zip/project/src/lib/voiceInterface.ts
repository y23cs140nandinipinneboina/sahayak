// Voice Command Interface for Teachers
export class VoiceCommandInterface {
  private recognition: SpeechRecognition | null = null;
  private isListening = false;
  private onResult: (transcript: string) => void = () => {};
  private onError: (error: string) => void = () => {};

  constructor() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      this.recognition = new SpeechRecognition();
      this.setupRecognition();
    }
  }

  private setupRecognition() {
    if (!this.recognition) return;

    this.recognition.continuous = false;
    this.recognition.interimResults = false;
    this.recognition.lang = 'hi-IN'; // Default to Hindi, can be changed

    this.recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      this.onResult(transcript);
      this.isListening = false;
    };

    this.recognition.onerror = (event) => {
      this.onError(`Speech recognition error: ${event.error}`);
      this.isListening = false;
    };

    this.recognition.onend = () => {
      this.isListening = false;
    };
  }

  setLanguage(language: string) {
    if (!this.recognition) return;
    
    const languageMap: { [key: string]: string } = {
      'hindi': 'hi-IN',
      'english': 'en-IN',
      'marathi': 'mr-IN',
      'bengali': 'bn-IN',
      'tamil': 'ta-IN',
      'telugu': 'te-IN',
      'gujarati': 'gu-IN',
      'kannada': 'kn-IN',
      'malayalam': 'ml-IN',
      'punjabi': 'pa-IN'
    };

    this.recognition.lang = languageMap[language] || 'en-IN';
  }

  startListening(onResult: (transcript: string) => void, onError: (error: string) => void) {
    if (!this.recognition) {
      onError('Speech recognition not supported in this browser');
      return;
    }

    if (this.isListening) {
      this.stopListening();
    }

    this.onResult = onResult;
    this.onError = onError;
    this.isListening = true;
    this.recognition.start();
  }

  stopListening() {
    if (this.recognition && this.isListening) {
      this.recognition.stop();
      this.isListening = false;
    }
  }

  isCurrentlyListening() {
    return this.isListening;
  }

  isSupported() {
    return this.recognition !== null;
  }
}

// Process voice commands using Gemini
export const processVoiceCommand = async (transcript: string, language: string = 'english') => {
  const apiKey = import.meta.env.VITE_GOOGLE_AI_API_KEY;
  
  if (!apiKey) {
    throw new Error('Google AI API key not configured');
  }

  const prompt = `
    You are a voice command processor for an AI teaching assistant called Sahayak.
    
    The teacher said: "${transcript}"
    Language context: ${language}
    
    Parse this command and return a JSON response with:
    {
      "action": "content_generator" | "worksheet_creator" | "knowledge_base" | "visual_aids" | "lesson_planner" | "game_generator" | "audio_assessment",
      "parameters": {
        // Relevant parameters based on the action
        "subject": "extracted subject",
        "grade": "extracted grade level",
        "topic": "extracted topic",
        "language": "${language}",
        "contentType": "story|explanation|worksheet|etc",
        "additional": "any other relevant info"
      },
      "confidence": 0.0-1.0,
      "clarification": "question to ask if unclear"
    }
    
    Examples:
    - "Create a math quiz for grade 3 in Hindi" → action: "game_generator", parameters: {subject: "math", grade: "3", language: "hindi", contentType: "quiz"}
    - "Make a story about animals" → action: "content_generator", parameters: {topic: "animals", contentType: "story"}
    - "Generate worksheet from this page" → action: "worksheet_creator"
    
    Return only valid JSON.
  `;

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: prompt
          }]
        }]
      })
    });

    if (!response.ok) {
      throw new Error('Failed to process voice command');
    }

    const data = await response.json();
    const content = data.candidates[0].content.parts[0].text;
    
    try {
      return JSON.parse(content);
    } catch {
      // If JSON parsing fails, return a generic response
      return {
        action: "knowledge_base",
        parameters: {
          question: transcript,
          language: language
        },
        confidence: 0.5,
        clarification: "I'll help you with that question."
      };
    }
  } catch (error) {
    console.error('Error processing voice command:', error);
    throw new Error('Failed to process voice command. Please try again.');
  }
};

// Text-to-Speech for story narration
export const narrateText = async (text: string, language: string = 'english'): Promise<string> => {
  // This would typically use Google Cloud Text-to-Speech API
  // For now, we'll use the browser's built-in speech synthesis
  
  return new Promise((resolve, reject) => {
    if (!('speechSynthesis' in window)) {
      reject(new Error('Text-to-speech not supported'));
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set language
    const languageMap: { [key: string]: string } = {
      'hindi': 'hi-IN',
      'english': 'en-IN',
      'marathi': 'mr-IN',
      'bengali': 'bn-IN',
      'tamil': 'ta-IN',
      'telugu': 'te-IN',
      'gujarati': 'gu-IN',
      'kannada': 'kn-IN',
      'malayalam': 'ml-IN',
      'punjabi': 'pa-IN'
    };

    utterance.lang = languageMap[language] || 'en-IN';
    utterance.rate = 0.8;
    utterance.pitch = 1.0;

    utterance.onend = () => {
      resolve('Speech completed');
    };

    utterance.onerror = (event) => {
      reject(new Error(`Speech synthesis error: ${event.error}`));
    };

    speechSynthesis.speak(utterance);
  });
};

// Stop any ongoing speech
export const stopNarration = () => {
  if ('speechSynthesis' in window) {
    speechSynthesis.cancel();
  }
};