import { collection, addDoc, getDocs, updateDoc, doc, deleteDoc, query, orderBy } from 'firebase/firestore';
import { db } from './firebase';

export interface StudentProfile {
  id?: string;
  name: string;
  grade: number;
  readingLevel: 'beginner' | 'intermediate' | 'advanced';
  subjects: string[];
  progressScores: {
    reading: number;
    math: number;
    science: number;
    overall: number;
  };
  voiceSampleUrl?: string;
  notes: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface AssessmentResult {
  id?: string;
  studentId: string;
  subject: string;
  type: 'reading' | 'worksheet' | 'quiz';
  score: number;
  maxScore: number;
  feedback: string;
  timestamp: Date;
}

// Student Profile Management
export const createStudentProfile = async (profile: Omit<StudentProfile, 'id' | 'createdAt' | 'updatedAt'>) => {
  try {
    const docRef = await addDoc(collection(db, 'students'), {
      ...profile,
      createdAt: new Date(),
      updatedAt: new Date()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error creating student profile:', error);
    throw error;
  }
};

export const getStudentProfiles = async (): Promise<StudentProfile[]> => {
  try {
    const q = query(collection(db, 'students'), orderBy('name'));
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as StudentProfile));
  } catch (error) {
    console.error('Error fetching student profiles:', error);
    throw error;
  }
};

export const updateStudentProfile = async (id: string, updates: Partial<StudentProfile>) => {
  try {
    const studentRef = doc(db, 'students', id);
    await updateDoc(studentRef, {
      ...updates,
      updatedAt: new Date()
    });
  } catch (error) {
    console.error('Error updating student profile:', error);
    throw error;
  }
};

export const deleteStudentProfile = async (id: string) => {
  try {
    await deleteDoc(doc(db, 'students', id));
  } catch (error) {
    console.error('Error deleting student profile:', error);
    throw error;
  }
};

// Assessment Management
export const saveAssessmentResult = async (result: Omit<AssessmentResult, 'id'>) => {
  try {
    const docRef = await addDoc(collection(db, 'assessments'), result);
    
    // Update student's progress scores
    const student = await getStudentProfiles();
    const targetStudent = student.find(s => s.id === result.studentId);
    
    if (targetStudent) {
      const percentage = (result.score / result.maxScore) * 100;
      const updatedScores = { ...targetStudent.progressScores };
      
      if (result.subject === 'reading') {
        updatedScores.reading = Math.round((updatedScores.reading + percentage) / 2);
      } else if (result.subject === 'math') {
        updatedScores.math = Math.round((updatedScores.math + percentage) / 2);
      } else if (result.subject === 'science') {
        updatedScores.science = Math.round((updatedScores.science + percentage) / 2);
      }
      
      updatedScores.overall = Math.round(
        (updatedScores.reading + updatedScores.math + updatedScores.science) / 3
      );
      
      await updateStudentProfile(result.studentId, { progressScores: updatedScores });
    }
    
    return docRef.id;
  } catch (error) {
    console.error('Error saving assessment result:', error);
    throw error;
  }
};

export const getStudentAssessments = async (studentId: string): Promise<AssessmentResult[]> => {
  try {
    const q = query(
      collection(db, 'assessments'),
      orderBy('timestamp', 'desc')
    );
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs
      .map(doc => ({ id: doc.id, ...doc.data() } as AssessmentResult))
      .filter(assessment => assessment.studentId === studentId);
  } catch (error) {
    console.error('Error fetching student assessments:', error);
    throw error;
  }
};